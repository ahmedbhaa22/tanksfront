<?php
/**
 * Created by PhpStorm.
 * User: Ash
 * Date: 11/20/2017
 * Time: 12:34 PM
 */

return [
    "offers_and_more" => "Offers and more"
];