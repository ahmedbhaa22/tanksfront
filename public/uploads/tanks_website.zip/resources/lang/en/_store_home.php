<?php
/**
 * Created by PhpStorm.
 * User: Ash
 * Date: 11/20/2017
 * Time: 12:32 PM
 */

return [
    "all_products" => "All products >>",
    "most_selling" => "Most selling products",
    "details"      => "Details",
    "add_to_cart"  => "Add to cart",
    "sr"           => "SR",
    "manufacturers"=> "Manufacturers",
    "all_manufacts"=> "All manufacturers >>",
    "no_most_selling" => "No most selling products found"
];