<?php
/**
 * Created by PhpStorm.
 * User: Ash
 * Date: 11/21/2017
 * Time: 10:12 AM
 */

return [
    "shipping_addresses" => "Shipping addresses",
    "my_orders"          => "My orders",
    "settings"           => "Settings",
    "logout"             => "Logout",
    "new_address"        => "Add new address",
    "main"               => "(Main address)"
];