<?php
/**
 * Created by PhpStorm.
 * User: Ash
 * Date: 11/20/2017
 * Time: 11:53 AM
 */

return [
    "new_events"        => "New Events",
    "products_services" => "Products",
    "about_us"          => "About us",
    "categories_services" => "Categories",
    "most_selling_services" => "Most Selling",
];