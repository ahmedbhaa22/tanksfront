<?php
/**
 * Created by PhpStorm.
 * User: Ash
 * Date: 11/21/2017
 * Time: 1:09 PM
 */

return [
    "search_results" => "Search Results",
    "no_results"     => "No Results",
    "results"        => " Results"
];