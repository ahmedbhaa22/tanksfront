<?php
/**
 * Created by PhpStorm.
 * User: Ash
 * Date: 11/21/2017
 * Time: 12:58 PM
 */

return [
    "rss" => "RSS Information Service",
    "what_is" => "What is RSS service?",
    "tanks"   => "Tanks",
    "content" => "Content",
    "details1" => "It is a service that gives you the ability to get latest news from you favorite websites once it is released.\n
    So instead of navigating these websites and search for news and articles in it, RSS service gives you all of them once they are released.\n
    And the news are formed into title, body, summary and link to the news source.",
    "details2" => "This service is for free.",
    "details3" => "To be able to use RSS service your web browser must support the RSS feature and must have a News Reader installed.",
];