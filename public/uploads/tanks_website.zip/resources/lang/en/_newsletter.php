<?php
/**
 * Created by PhpStorm.
 * User: Ash
 * Date: 11/20/2017
 * Time: 11:58 AM
 */

return [
    "subscribe"      => "Subscribe now and get a coupon of 150 SR",
    "special_offers" => "Subscribe now and get special offers & discounts",
    "enter_email"    => "Enter you email",
    "register"       => "Subscribe",
    "close"          => "Close",
];