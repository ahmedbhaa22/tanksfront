<?php
/**
 * Created by PhpStorm.
 * User: Ash
 * Date: 11/20/2017
 * Time: 4:49 PM
 */

return [
    "compare_products" => "Compare products",
    "name"             => "Name",
    "description"      => "Description",
    "delivery"         => "Delivery",
    "factory"          => "Factory",
    "price"            => "Price",
    "avail_colors"     => "Available colors",
    "delivery_places"  => "Delivery places",
];