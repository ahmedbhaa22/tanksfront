<?php
/**
 * Created by PhpStorm.
 * User: Ash
 * Date: 11/21/2017
 * Time: 10:40 AM
 */

return [
    "orders" => "My Orders",
    "order_no" => "Order number: ",
    "total_price" => "Total price: ",
    "add_purchase_prove"=>" Add Purchase Prove",
    "view_purchase_prove" =>"View Purchase Prove",
    "payment_receipt" =>"Purchase Prove"
];