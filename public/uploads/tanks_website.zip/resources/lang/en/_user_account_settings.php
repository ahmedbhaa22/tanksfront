<?php
/**
 * Created by PhpStorm.
 * User: Ash
 * Date: 11/20/2017
 * Time: 5:13 PM
 */

return [
    "full_name"  => "Full name",
    "settings"   => "Settings",
    "birthdate"   => "Birth Date",
    "country"    => "Country",
    "city"       => "City",
    "region"     => "Region",
    "mobile"     => "Mobile number",
    "email"      => "E-mail",
    "subscribe"  => "Subscribe to get latest news",
    "save"       => "Save",
    "cancel"     => "Cancel",
    "change_pass" => "Change Password"
];