<?php
/**
 * Created by PhpStorm.
 * User: Ash
 * Date: 11/20/2017
 * Time: 12:04 PM
 */

return [
    "contact_us"    => "Contact Us",
    "join_us"       => "Join Us",
    "links"         => "Links",
    "faq"           => "FAQ",
    "terms"         => "Terms and conditions",
    "maintenance"   => "Maintenance",
    "site_map"      => "Site map",
    "rss"           => "RSS",
    "brochures"     => "Brochures",
    "branches"      => "Branches",
    "copy_right"    => "Copy Right",
    "all_rights"    => "All rights reserved",
    "arabian_tanks" => "Arabian Tanks Company",
];