<?php
/**
 * Created by PhpStorm.
 * User: Ash
 * Date: 11/21/2017
 * Time: 11:17 AM
 */

return [
    "join_us"      => "Join Us",
    "name"         => "Name",
    "age"          => "Age",
    "country"      => "Country",
    "mobile"       => "Mobile Number",
    "address"      => "Address",
    "job_title"    => "Job Title",
    "experience"   => "Previous Experience",
    "email"        => "E-mail",
    "attach_cv"    => "Attach CV",
    "upload"       => "Upload File",
    "have_account" => "Already have account ? ..",
    "login"        => "Login",
    "save"         => "Save",
];