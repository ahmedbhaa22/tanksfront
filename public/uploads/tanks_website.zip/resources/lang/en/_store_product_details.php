<?php
/**
 * Created by PhpStorm.
 * User: Ash
 * Date: 11/20/2017
 * Time: 2:07 PM
 */

return [
    "product_details" => "Product details",
    "factory"         => "Factory :",
    "color"           => "Color :",
    "delivery_place"  => "Delivery place",
    "best_price"      => "Best Price",
    "sr"              => "SR",
    "now"             => "Now",
    "save"            => "Save",
    "share"           => "Share",
    "fast_delivery"   => "Fast delivery",
    "we_promise"      => "We promise",
    "guarantee"       => "Guarantee",
    "add_to_cart"     => "Add to cart",
    "product_description" => "Product description",
    "specifications"      => "Specifications",
    "comments"            => "Comments",
    "add_comment"         => "Add comment",
    "related_products"    => "Related products",
    "details"             => "Details",
];