<?php
/**
 * Created by PhpStorm.
 * User: Ash
 * Date: 11/21/2017
 * Time: 10:37 AM
 */

return [
    "reset"    => "Reset Password",
    "email"    => "E-mail",
    "continue" => "Continue",
    "password" => "Password",
    "confirm_password" => "Confirm Password",
    "reset_send" => "Send"
];