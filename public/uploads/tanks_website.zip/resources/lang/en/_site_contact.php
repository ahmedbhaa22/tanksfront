<?php
/**
 * Created by PhpStorm.
 * User: Ash
 * Date: 11/21/2017
 * Time: 12:16 PM
 */

return [
    "send"  => "Send to customer service",
    "name"  => "Name",
    "email" => "E-mail",
    "inq"   => "Your Inquiry",
    "save"  => "Send"
];