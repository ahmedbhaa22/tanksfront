<?php
/**
 * Created by PhpStorm.
 * User: Ash
 * Date: 11/20/2017
 * Time: 4:55 PM
 */

return [
    "wishlist"         => "WishList",
    "discount_percent" => "Discount percent: ",
    "price"            => "Price: ",
    "factory"          => "Factory: ",
    "remove_wishlist"  => "Remove WishList"
];