<?php
/**
 * Created by PhpStorm.
 * User: Ash
 * Date: 11/20/2017
 * Time: 4:03 PM
 */

return [
    "share"          => "Share",
    "delivery_place" => "Delivery place",
    "best_price"     => "Best price",
    "sr"             => "SR",
    "add_to_cart"    => "Add to cart",
    "offer_to_date_or_qty" => "Offer available until finished or until ",
    "offer_to_date"        => "Offer available until ",
    "offer_to_qty"         => "Offer available until quantity finished",
    "offer_products"       => "Offer products",
    "qty"                  => "Qty: ",
    "color"                => "Color: ",
    "total_price"          => "Total price: ",
    "now"                  => "Now",
    "save"                 => "Save",
];