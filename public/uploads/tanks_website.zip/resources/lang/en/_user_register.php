<?php
/**
 * Created by PhpStorm.
 * User: Ash
 * Date: 11/21/2017
 * Time: 10:25 AM
 */

return [
    "register" => "Register new account",
    "email"    => "E-mail",
    "required" => "You have to fill this field",
    "username" => "User Name",
    "password" => "Password",
    "re-pass"  => "Re-type Password",
    "name"     => "Full Name",
    "mobile"   => "Mobile Number",
    "save"     => "Create Account",
    "have_account" => "Already has account? ..",
    "login"        => "Login",
];