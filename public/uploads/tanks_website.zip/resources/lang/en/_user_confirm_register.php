<?php
/**
 * Created by PhpStorm.
 * User: Ash
 * Date: 11/20/2017
 * Time: 5:39 PM
 */

return [
    "confirm_register" => "Confirm Register",
    "back_to_home"     => "Click here to go back to login page"
];