<?php
/**
 * Created by PhpStorm.
 * User: Ash
 * Date: 11/21/2017
 * Time: 1:32 PM
 */

return [
    "call_on"        => "To know prices please call: ",
    "general_view"   => "General view",
    "request_visit"  => "Request visit",
    "required"       => "All fields are required",
    "suggested_date" => "Suggested Visit Date",
    "name"           => "Name",
    "mobile"         => "Mobile Number",
    "visit_place"    => "Visit Place",
    "save"           => "Save"
];