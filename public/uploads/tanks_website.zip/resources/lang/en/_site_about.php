<?php
/**
 * Created by PhpStorm.
 * User: Ash
 * Date: 11/21/2017
 * Time: 10:46 AM
 */

return [
    "gallery" => "Arabian Tanks Gallery",
    "close"   => "Close",
];