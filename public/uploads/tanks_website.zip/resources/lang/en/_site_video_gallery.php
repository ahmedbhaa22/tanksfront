<?php
/**
 * Created by PhpStorm.
 * User: Ash
 * Date: 11/21/2017
 * Time: 1:41 PM
 */

return [
    "gallery" => "Arabian Tanks Video Gallery",
    "close"   => "Close"
];