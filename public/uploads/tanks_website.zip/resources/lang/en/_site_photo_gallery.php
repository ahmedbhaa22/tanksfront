<?php
/**
 * Created by PhpStorm.
 * User: Ash
 * Date: 11/21/2017
 * Time: 12:14 PM
 */

return [
    "gallery" => "Arabian tanks photo gallery",
    "close"   => "Close"
];
