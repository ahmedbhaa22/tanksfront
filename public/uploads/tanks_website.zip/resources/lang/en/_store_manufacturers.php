
<?php
/**
 * Created by PhpStorm.
 * User: Ash
 * Date: 11/20/2017
 * Time: 4:48 PM
 */

return [
    "manufacturers" => "Manufacturers",
];