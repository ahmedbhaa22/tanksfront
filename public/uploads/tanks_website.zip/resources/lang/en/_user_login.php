<?php
/**
 * Created by PhpStorm.
 * User: Ash
 * Date: 11/21/2017
 * Time: 10:21 AM
 */

return [
    "login"      => "Login",
    "email"      => "E-mail",
    "password"   => "Password",
    "no_account" => "Create new account",
    "forgot"     => "Forgot password?",
];