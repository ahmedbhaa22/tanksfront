<?php
/**
 * Created by PhpStorm.
 * User: Ash
 * Date: 11/21/2017
 * Time: 1:39 PM
 */

return [
    "terms" => "Terms And Conditions"
];