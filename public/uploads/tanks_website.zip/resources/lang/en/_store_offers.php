<?php
/**
 * Created by PhpStorm.
 * User: Ash
 * Date: 11/20/2017
 * Time: 4:00 PM
 */

return [
    "choose_region" => "Choose region",
    "all_regions"   => "All regions",
    "offers"        => "Offers",
];