<?php
/**
 * Created by PhpStorm.
 * User: Ash
 * Date: 11/21/2017
 * Time: 12:29 PM
 */

return [
    "factory" => "Al-Zamil Factory",
];