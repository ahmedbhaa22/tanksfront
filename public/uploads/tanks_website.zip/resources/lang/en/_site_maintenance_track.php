<?php
/**
 * Created by PhpStorm.
 * User: Ash
 * Date: 11/21/2017
 * Time: 12:37 PM
 */

return [
    "track"        => "Maintenance Track",
    "required"     => "This fields is required",
    "code"         => "Maintenance Code",
    "confirm"      => "Confirm",
    "more"         => "More about maintenance process",
    "release_date" => "Release Date",
    "confirm_date" => "Confirm Date",
    "delivered"    => "Delivered",
    "canceled"     => "Canceled"
];