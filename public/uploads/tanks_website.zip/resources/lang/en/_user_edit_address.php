<?php
/**
 * Created by PhpStorm.
 * User: Ash
 * Date: 11/20/2017
 * Time: 5:42 PM
 */

return [
    "edit_address" => "Edit shipping address",
    "country"      => "Country",
    "city"         => "City",
    "region"       => "Region",
    "addr_details" => "Address details",
    "postal"       => "Postal",
    "main"         => "Main address",
    "save"         => "Save",
    "cancel"       => "Cancel"
];