<?php
/**
 * Created by PhpStorm.
 * User: Ash
 * Date: 11/20/2017
 * Time: 5:34 PM
 */

return [
    "change_password" => "Change password",
    "old"             => "Old password",
    "new"             => "New password",
    "re-new"          => "Confirm new password",
    "save"            => "Save",
    "cancel"          => "Cancel"
];