<?php
/**
 * Created by PhpStorm.
 * User: Ash
 * Date: 11/20/2017
 * Time: 5:20 PM
 */

return [
    "add_address"  => "Add address",
    "country"      => "Country",
    "city"         => "City",
    "region"       => "Region",
    "addr_details" => "Address Details",
    "postal"       => "Postal code",
    "main"         => "Main address",
    "save"         => "Save",
    "cancel"       => "Cancel"
];