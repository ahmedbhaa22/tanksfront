<?php
/**
 * Created by PhpStorm.
 * User: Ash
 * Date: 11/20/2017
 * Time: 12:46 PM
 */

return [
    "shopping_center" => "Shopping center",
    "result"          => "Result",
    "by_price"        => "By price",
    "by_name"         => "By name",
    "asc"             => "Ascending",
    "desc"            => "Descending",
    "sr"              => "SR",
    "details"         => "Details",
    "add_to_cart"     => "Add to cart",
    "discount_percent"=> "Discount percent : ",
    "price"           => "Price : ",
    "factory"         => "Factory : ",
    "sort"            => "Sort",
    "sort_type"       => "Sort type",
    //
    "filter"          => "Filter",
    "manufacturers"   => "Manufacturers",
    "categories"      => "Categories",
    "all"             => "All"
];