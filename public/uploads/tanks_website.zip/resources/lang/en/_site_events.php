<?php
/**
 * Created by PhpStorm.
 * User: Ash
 * Date: 11/21/2017
 * Time: 12:27 PM
 */

return [
    "events" => "Events",
    "more"   => "More",
];