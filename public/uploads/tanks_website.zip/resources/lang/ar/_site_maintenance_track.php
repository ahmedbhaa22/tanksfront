<?php
/**
 * Created by PhpStorm.
 * User: Ash
 * Date: 11/21/2017
 * Time: 12:37 PM
 */


return [
    "track"        => "تتبع الصيانة",
    "required"     => "يجب عليك ملأ هذا الحقل",
    "code"         => "كود الصيانة",
    "confirm"      => "تأكيد",
    "more"         => "المزيد عن عملية الصيانة",
    "release_date" => "تاريخ الإصدار",
    "confirm_date" => "تاريخ التأكيد",
    "delivered"    => "تم التسليم",
    "canceled"     => "تم الإلغاء"
];