<?php
/**
 * Created by PhpStorm.
 * User: Ash
 * Date: 11/20/2017
 * Time: 5:13 PM
 */

return [
    "full_name"  => "الأسم بالكامل",
    "settings"   => "الضبط",
    "birthdate"   => "تاريخ الميلاد",
    "country"    => "البلد",
    "city"       => "المدينة",
    "region"     => "الحي",
    "mobile"     => "الموبايل",
    "email"      => "البريد الإلكتروني",
    "subscribe"  => "أشترك لتصلك أحدث الأخبار",
    "save"       => "حفظ",
    "cancel"     => "إلغاء",
    "change_pass" => "تغيير كلمة السر"
];