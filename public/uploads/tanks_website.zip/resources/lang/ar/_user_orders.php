<?php
/**
 * Created by PhpStorm.
 * User: Ash
 * Date: 11/21/2017
 * Time: 10:40 AM
 */

return [
    "orders" => "طلباتي",
    "order_no" => "رقم الطلب: ",
    "total_price" => "إجمالي السعر: ",
    "view_purchase_prove" =>"عرض اثبات الدفع",
    "add_purchase_prove" => "إضافة اثبات الدفع"
];