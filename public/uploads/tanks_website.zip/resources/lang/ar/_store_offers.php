<?php
/**
 * Created by PhpStorm.
 * User: Ash
 * Date: 11/20/2017
 * Time: 4:00 PM
 */

return [
    "choose_region" => "أختر منطقة",
    "all_regions"   => "كل المناطق",
    "offers"        => "العروض",
];