<?php
/**
 * Created by PhpStorm.
 * User: Ash
 * Date: 11/20/2017
 * Time: 12:46 PM
 */

return [
    "shopping_center" => "مركز التسوق",
    "result"          => "نتيجة",
    "by_price"        => "بالسعر",
    "by_name"         => "بالأسم",
    "asc"             => "تصاعدي",
    "desc"            => "تنازلي",
    "sr"              => "ريال",
    "details"         => "التفاصيل",
    "add_to_cart"     => "أضف لعربة التسوق",
    "discount_percent"=> "نسبة الخصم : ",
    "price"           => "السعر : ",
    "factory"         => "المصنع : ",
    "sort"            => "رتب",
    "sort_type"       => "نوع الترتيب",
    //
    "filter"          => "فلتر",
    "manufacturers"   => "المصنعين",
    "categories"      => "الفئات",
    "all"             => "الكل"
];