<?php
/**
 * Created by PhpStorm.
 * User: Ash
 * Date: 11/20/2017
 * Time: 4:55 PM
 */

return [
    "wishlist"         => "القائمة المفضلة",
    "discount_percent" => "نسبة الخصم: ",
    "price"            => "السعر: ",
    "factory"          => "المصنع: ",
    "remove_wishlist"  => "مسح القائمة المفضلة"
];