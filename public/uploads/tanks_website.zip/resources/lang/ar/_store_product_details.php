<?php
/**
 * Created by PhpStorm.
 * User: Ash
 * Date: 11/20/2017
 * Time: 2:07 PM
 */

return [
    "product_details" => "تفاصيل المنتج",
    "factory"         => "المصنع :",
    "color"           => "اللون :",
    "delivery_place"  => "مكان التسليم",
    "best_price"      => "أفضل سعر",
    "sr"              => "ريال",
    "now"             => "الآن",
    "save"            => "وفر",
    "share"           => "مشاركة",
    "fast_delivery"   => "سرعة التوصيل",
    "we_promise"      => "نحن نوعدك",
    "guarantee"       => "ضمان",
    "add_to_cart"     => "أضف لعربة التسوق",
    "product_description" => "وصف المنتج",
    "specifications"      => "المواصفات",
    "comments"            => "التعليقات",
    "add_comment"         => "أضف تعليق",
    "related_products"    => "منتجات ذات صلة",
    "details"             => "التفاصيل",
];