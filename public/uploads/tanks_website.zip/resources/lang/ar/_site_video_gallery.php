<?php
/**
 * Created by PhpStorm.
 * User: Ash
 * Date: 11/21/2017
 * Time: 1:41 PM
 */

return [
    "gallery" => "معرض فيديو العربية لخزانات",
    "close"   => "أغلق"
];