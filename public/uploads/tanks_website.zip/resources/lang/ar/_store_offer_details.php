<?php
/**
 * Created by PhpStorm.
 * User: Ash
 * Date: 11/20/2017
 * Time: 4:03 PM
 */

return [
    "share"          => "مشاركة",
    "delivery_place" => "مكان التسليم",
    "best_price"     => "أفضل سعر",
    "sr"             => "ريال",
    "add_to_cart"    => "أضف لعربة التسوق",
    "offer_to_date_or_qty" => "العرض ساري حتى نفاذ الكمية أو حتى ",
    "offer_to_date"        => "العرض ساري حتى ",
    "offer_to_qty"         => "العرض ساري حتى نفاذ الكمية ",
    "offer_products"       => "المنتجات داخل العرض",
    "qty"                  => "الكمية: ",
    "color"                => "اللون: ",
    "total_price"          => "إجمالي السعر: ",
    "now"                  => "الآن",
    "save"                 => "وفر",
];