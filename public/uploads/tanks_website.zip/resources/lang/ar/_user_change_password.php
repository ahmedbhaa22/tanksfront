<?php
/**
 * Created by PhpStorm.
 * User: Ash
 * Date: 11/20/2017
 * Time: 5:34 PM
 */

return [
    "change_password" => "تغيير كلمة  المرور",
    "old"             => "كلمة المرور القديمة",
    "new"             => "كلمة المرور الجديدة",
    "re-new"          => "تأكيد كلمة المرور الجديدة",
    "save"            => "حفظ",
    "cancel"          => "إلغاء"
];