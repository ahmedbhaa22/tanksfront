<?php
/**
 * Created by PhpStorm.
 * User: Ash
 * Date: 11/21/2017
 * Time: 12:35 PM
 */

return [
    "maintenance" => "عملية الصيانة",
    "track"       => "تتبع الصيانة"
];