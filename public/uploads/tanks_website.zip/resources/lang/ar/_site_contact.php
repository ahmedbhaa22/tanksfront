<?php
/**
 * Created by PhpStorm.
 * User: Ash
 * Date: 11/21/2017
 * Time: 12:16 PM
 */

return [
    "send"  => "أرسل لخدمة العملاء",
    "name"  => "الأسم",
    "email" => "البريد الإلكتروني",
    "inq"   => "استفسارك",
    "save"  => "إرسال"
];