<?php
/**
 * Created by PhpStorm.
 * User: Ash
 * Date: 11/21/2017
 * Time: 11:17 AM
 */

return [
    "join_us"      => "أنضم لنا",
    "name"         => "الأسم",
    "age"          => "السن",
    "country"      => "البلد",
    "mobile"       => "رقم الموبايل",
    "address"      => "العنوان",
    "job_title"    => "المسمى الوظيفي",
    "experience"   => "الخبرة السابقة",
    "email"        => "البريد الإلكتروني",
    "attach_cv"    => "أرفق ال CV ",
    "upload"       => "أرفع الملف",
    "have_account" => "هل لديك حساب ؟ ..",
    "login"        => "تسجيل الدخول",
    "save"         => "حفظ",
];