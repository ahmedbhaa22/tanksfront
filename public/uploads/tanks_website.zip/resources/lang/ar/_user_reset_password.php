<?php
/**
 * Created by PhpStorm.
 * User: Ash
 * Date: 11/21/2017
 * Time: 10:37 AM
 */

return [
    "reset"    => "إعادة تعيين كلمة المرور",
    "email"    => "البريد الإلكتروني",
    "continue" => "متابعة",
    "password" => "كلمة المرور",
    "confirm_password" => "تأكيد كلمة المرور",
    "reset_send" => "إرسال"
];