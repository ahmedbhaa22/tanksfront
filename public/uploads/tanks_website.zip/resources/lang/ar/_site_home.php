<?php
/**
 * Created by PhpStorm.
 * User: Ash
 * Date: 11/20/2017
 * Time: 11:53 AM
 */

return [
    "new_events"        => "أجدد الأحداث",
    "products_services" => "المنتجات",
    "about_us"          => "من نحن",
    "categories_services" => "التصنيفات",
    "most_selling_services" => "الأكثر مبيعا",
];