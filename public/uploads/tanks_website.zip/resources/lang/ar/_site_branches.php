<?php
/**
 * Created by PhpStorm.
 * User: Ash
 * Date: 11/21/2017
 * Time: 11:03 AM
 */

return [
    "branches"        => "ك الفروع",
    "choose_region"   => "أختر منطقة",
    "all_regions"     => "كل المناطق",
];