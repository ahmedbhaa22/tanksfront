<?php
/**
 * Created by PhpStorm.
 * User: Ash
 * Date: 11/20/2017
 * Time: 4:49 PM
 */

return [
    "compare_products" => "مقارنة المنتجات",
    "name"             => "الأسم",
    "description"      => "الوصف",
    "delivery"         => "التسليم",
    "factory"          => "المصنع",
    "price"            => "السعر",
    "avail_colors"     => "الألوان المتاحة",
    "delivery_places"  => "أماكن التسليم",
];