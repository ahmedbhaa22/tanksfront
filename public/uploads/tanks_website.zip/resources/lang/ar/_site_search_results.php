<?php
/**
 * Created by PhpStorm.
 * User: Ash
 * Date: 11/21/2017
 * Time: 1:09 PM
 */

return [
    "search_results" => "نتائج البحث",
    "no_results"     => "لا توجد نتائج",
    "results"        => " نتائج"
];