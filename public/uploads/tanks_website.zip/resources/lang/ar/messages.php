<?php
return [
    'login_success' => "تم تسجيل دخولك بنجاح!",
    'auth_required' => "سجل دخولك أولا",
    'logout_success' => "تم تسجيل خروجك بنجاح",
    'add_shipping_success' => "تم اضافة عنوان الشحن بنجاح",
    'edit_shipping_success' => "تم تعديل عنوان الشحن بنجاح",
    'password_changed' => "تم تعديل كلمة السر بنجاح",
    'must_upload_certificate' => "يجب عليك رفع شهادة الدفع",
    'invalid_img_extension' => "صيغة ملف الشهادة غير صحيحة. الصيغ المدعومة jpg, png, gif",
    'validation_failed' => 'خطأ أثناء العملية'
];