<?php
/**
 * Created by PhpStorm.
 * User: Ash
 * Date: 11/20/2017
 * Time: 12:32 PM
 */

return [
    "all_products" => "كل المنتجات >>",
    "most_selling" => " المنتجات الأكثر مبيعاً",
    "details"      => "التفاصيل",
    "add_to_cart"  => "أضف لعربة التسوق",
    "sr"           => "ريال",
    "manufacturers"=> "المصنعين",
    "all_manufacts"=> "كل المصنعين >>",
    "no_most_selling" => "لا توجد منتجات أكثر مبيعاً"
];