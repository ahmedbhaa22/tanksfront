<?php
/**
 * Created by PhpStorm.
 * User: Ash
 * Date: 11/21/2017
 * Time: 12:31 PM
 */

return [
    "faq"         => "أسئلة و أجوبة",
    "general"     => "أسئلة عامة",
    "maintenance" => "أسئلة خاصة بالصيانة",
    "products"    => "أسئلة خاصة بالمنتجات",
];