<?php
/**
 * Created by PhpStorm.
 * User: Ash
 * Date: 11/20/2017
 * Time: 11:58 AM
 */

return [
    "subscribe"      => "سجل الآن واحصل على كوبون بقيمة 150 ريال سعودي",
    "special_offers" => "سجل الآن و احصل على عروض مميزة وتخفيضات خاصة",
    "enter_email"    => "أدخل بريدك الإلكتروني",
    "register"       => "أشترك",
    "close"          => "أغلق",
];