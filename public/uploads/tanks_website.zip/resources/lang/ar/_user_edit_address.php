<?php
/**
 * Created by PhpStorm.
 * User: Ash
 * Date: 11/20/2017
 * Time: 5:42 PM
 */

return [
    "edit_address"  => "تعديل عنوان",
    "country"      => "البلد",
    "city"         => "المدينة",
    "region"       => "الحي",
    "addr_details" => "تفاصيل العنوان",
    "postal"       => "الرمز البريدي",
    "main"         => "العنوان الرئيسي",
    "save"         => "حفظ",
    "cancel"       => "إلغاء"
];