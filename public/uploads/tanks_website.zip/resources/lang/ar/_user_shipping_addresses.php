<?php
/**
 * Created by PhpStorm.
 * User: Ash
 * Date: 11/21/2017
 * Time: 10:12 AM
 */

return [
    "shipping_addresses" => "عناوين الشحن",
    "my_orders"          => "طلباتي",
    "settings"           => "الضبط",
    "logout"             => "خروج",
    "new_address"        => "إضافة عنوان جديد",
    "main"               => "(العنوان الرئيسي)"
];