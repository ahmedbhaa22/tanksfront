<?php
/**
 * Created by PhpStorm.
 * User: Ash
 * Date: 11/20/2017
 * Time: 5:39 PM
 */

return [
    "confirm_register" => "تأكيد حسابك",
    "back_to_home"     => "اضغط هنا للرجوع للذهاب الى صفحة الدخول"
];