<?php
/**
 * Created by PhpStorm.
 * User: Ash
 * Date: 11/21/2017
 * Time: 10:25 AM
 */

return [
    "register" => "إنشاء حساب جديد",
    "email"    => "البريد الإلكتروني",
    "required" => "يجب عليك ملأ هذا الحقل",
    "username" => "أسم المستخدم",
    "password" => "كلمة السر",
    "re-pass"  => "تأكيد كلمة السر",
    "name"     => "الأسم بالكامل",
    "mobile"   => "رقم الجوال",
    "save"     => "إنشاء الحساب",
    "have_account" => "تمتلك حساب ؟ ..",
    "login"        => "تسجيل الدخول",
];