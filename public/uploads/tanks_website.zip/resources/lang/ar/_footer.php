<?php
/**
 * Created by PhpStorm.
 * User: Ash
 * Date: 11/20/2017
 * Time: 12:04 PM
 */

return [
    "contact_us"    => "أتصل بنا",
    "join_us"       => "أنضم لنا",
    "links"         => "روابط",
    "faq"           => "أسئلة و أجوبة",
    "terms"         => "الشروط و الأحكام",
    "maintenance"   => "الصيانة",
    "site_map"      => "خريطة الموقع",
    "rss"           => "RSS",
    "brochures"     => "البرشورات",
    "branches"      => "الفروع",
    "copy_right"    => "حقوق النشر",
    "all_rights"    => "جميع الحقوق محفوظة",
    "arabian_tanks" => "الشركة العربية لخزانات المياه",
];