<?php
/**
 * Created by PhpStorm.
 * User: Ash
 * Date: 11/21/2017
 * Time: 1:32 PM
 */

return [
    "call_on"        => "لمعرفة الأسعار برجاء الإتصال على: ",
    "general_view"   => "نظرة عامة",
    "request_visit"  => "طلب زيارة",
    "required"       => "جميع الحقول مطلوبة",
    "suggested_date" => "التاريخ المقترح لزيارة",
    "name"           => "الأسم",
    "mobile"         => "رقم الموبايل",
    "visit_place"    => "مكان الزيارة",
    "save"           => "حفظ"
];