@extends('template')

@section('title', "Sitemap")

@section('content')
    <div class="container-fluid no-padding page-body">
    <div class="container">
    </div>
    </div>
@endsection