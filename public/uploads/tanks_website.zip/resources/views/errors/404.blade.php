@extends('template')

@section('title', "404 Not Found")

@section('content')
    <div class="container-fluid no-padding about-page page-body">
        <div class="container">

            <div class="container">

                <h3 class="main-title uppercase text-center">
                    404 Not Found
                </h3>
            </div>
        </div>
    </div>

@endsection