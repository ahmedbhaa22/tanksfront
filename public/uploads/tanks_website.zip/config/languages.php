<?php
return [
    'en' => 'English',
    'ar' => 'العربية',
];