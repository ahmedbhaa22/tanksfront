<div class="col-md-3 col-sm-4 filters-section no-padding">
    <button type="button" class="btn" data-toggle="collapse" data-target="#filter-sec"><?php echo e(__('_store_shopping_center.filter')); ?></button>
    <div id="filter-sec" class="collapse">
        <form method="GET" id="filter-form">
            <h4 class="uppercase text-primary"><?php echo e(__('_store_shopping_center.filter')); ?></h4>
            <div class="col-sm-12 col-xs-6 no-padding">
                <p><b class="col-xs-12 no-padding gap15"><?php echo e(__('_store_shopping_center.manufacturers')); ?></b></p>

                <?php if($manufacturersList): ?>
                    <?php $checkedManfs = request('filterManf'); ?>
                    <?php $__currentLoopData = $manufacturersList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="row">
                            <div class="col-sm-2 col-xs-3">
                                <input type="checkbox" id="m<?php echo e($key); ?>" <?php echo e((!empty($checkedManfs)?(in_array($m['id'], $checkedManfs)?"checked":""):"")); ?>  class="filter-manufacturer" name="filterManf[]" value="<?php echo e($m['id']); ?>">
                                <label for="m<?php echo e($key); ?>"></label>
                            </div>
                            <div class="col-sm-10 col-xs-9">
                                <p class=""><?php echo e($m['name']); ?> <span class="badge"><?php echo e($m['items_count']); ?></span></p>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>

            </div>
            <div class="col-sm-12 col-xs-6 no-padding">
            <p><b class="col-xs-12 no-padding gap15"><?php echo e(__('_store_shopping_center.categories')); ?></b></p>

            <div class="row">
                <div class="col-sm-2 col-xs-3">
                    <input type="checkbox" id="c0" class="filter-category" name="" value="">
                    <label for="c0"></label>
                </div>
                <div class="col-sm-10 col-xs-9">
                    <p class=""><?php echo e(__('_store_shopping_center.all')); ?><span class="badge"><?php echo e($allCategoriesProductCount); ?></span></p>
                </div>
            </div>

            <?php if($categoriesList): ?>
                <?php $checkedCats = request('filterCategory'); ?>
                    <?php $__currentLoopData = $categoriesList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="row">
                            <div class="col-sm-2 col-xs-3">
                                <input type="checkbox" id="c<?php echo e($key+1); ?>" <?php echo e((!empty($checkedCats)?(in_array($cat['id'], $checkedCats)?"checked":""):"")); ?> class="filter-category sub-categories" name="filterCategory[]" value="<?php echo e($cat['id']); ?>">
                                <label for="c<?php echo e($key+1); ?>"></label>
                            </div>
                            <div class="col-sm-10 col-xs-9">
                                <p class=""><?php echo e($cat['name']); ?> <span class="badge"><?php echo e($cat['items_count']); ?></span></p>
                            </div>
                        </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>

        </div>
        </form>
    </div>
</div>
