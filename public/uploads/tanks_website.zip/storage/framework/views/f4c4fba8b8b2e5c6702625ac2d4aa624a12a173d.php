<?php $__env->startSection('title', "Account Settings"); ?>

<?php $__env->startSection('content'); ?>

    <div class="container-fluid no-padding page-body">
        <div class="container">

            <?php echo e(Breadcrumbs::render('account-settings')); ?>


            <div class="account-div">

                <?php echo $__env->make('partials._userProfileSidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                <div class="bordred-account-div col-md-9 col-sm-7 col-xs-12">
                    <form class="bordered col-xs-12" method="post">

                        <h3 class="uppercase">
                            <?php echo e(__('_user_account_settings.settings')); ?>

                        </h3>

                        <?php echo $__env->make('partials._formMessages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


                        <div class="form-group  float-label-control">
                            <label for="name"><?php echo e(__('_user_account_settings.full_name')); ?></label>
                            <input type="text" class="form-control" id="name" name="name" value="<?php echo e(old('name')!=""?old('name'):Session::get('name')); ?>">
                        </div>
                        <?php echo e(csrf_field()); ?>

                        <div class="form-group  float-label-control">
                            <label for="brithdate"><?php echo e(__('_user_account_settings.birthdate')); ?></label>
                            <!-- <input type="date" class="form-control" id="brithdate"> -->

                            
                            <input type="date" id="date" class="form-control floating-label" name="birthdate" value="<?php echo e(old('birthDate')!=null?old('birthDate'):(\Session::get('birth_date')!=null?date('Y-m-d', Session::get('birth_date')):'')); ?>">
                        </div>
                        <div class="form-group">
                            <label for="country"><?php echo e(__('_user_account_settings.country')); ?></label>
                            <select class="form-control" id="country" name="country_id">
                                <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($country['id']); ?>"
                                            <?php if(Session::get('country_id') == $country['id']): ?>
                                                selected
                                            <?php endif; ?>
                                            ><?php echo e($country['name']); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                         <div class="form-group">
                            <label for="district"><?php echo e(__('_user_account_settings.region')); ?></label>
                            <select class="form-control" name="region_id" id="region_id">
                                <?php $__currentLoopData = $regions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $region): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($region['id']); ?>"
                                            <?php if(Session::get('region_id') == $region['id']): ?>
                                                selected
                                            <?php endif; ?>
                                            ><?php echo e($region['name']); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="city"><?php echo e(__('_user_account_settings.city')); ?></label>
                            <select class="form-control" id="city_id" name="city_id">
                                <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($city['id'] == Session::get('city_id')): ?>
                                        <option selected value="<?php echo e($city['id']); ?>"><?php echo e($city['name']); ?></option>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="form-group  float-label-control">
                            <label for="mobile"><?php echo e(__('_user_account_settings.mobile')); ?></label>
                            <input type="tel" class="form-control" id="mobile" name="mobile" value="<?php echo e(old('mobile')!=""?old('mobile'):Session::get('mobile')); ?>">
                        </div>
                        <div class="form-group  float-label-control">
                            <label for="email"><?php echo e(__('_user_account_settings.email')); ?></label>
                            <input type="email" class="form-control" id="email" name="email" value="<?php echo e(old('email')!=""?old('email'):Session::get('email')); ?>">
                        </div>
                        <div class="form-group">
                            <label for="subscribe" class="lbl-for-toggle"><?php echo e(__('_user_account_settings.subscribe')); ?></label>
                            <label class="switch pull-right">
                                <input name="subscribe" id="newsletter-subscribe" type="checkbox"
                                        <?php if(\Session::get('is_subscribed') != null && \Session::get('is_subscribed') == 1): ?>
                                            checked
                                        <?php endif; ?>
                                        >
                                <span class="slider round"></span>
                            </label>
                        </div>
                        <div class="row">
                            <div class="col-sm-6 col-xs-12">
                                <button type="submit" class="btn form-submit-btn btn-outline-custom  btn-blue col-xs-12 no-padding uppercase"><?php echo e(__('_user_account_settings.save')); ?></button>
                            </div>
                            <div class="col-sm-6 col-xs-12">
                                <button type="button" onclick="location.assign('<?php echo e(route('user-orders')); ?>')" class="btn form-submit-btn col-xs-12 no-padding uppercase cancel-btn"><?php echo e(__('_user_account_settings.cancel')); ?></button>
                            </div>
                        </div>
                    </form>
                    <div class="col-md-6 col-md-offset-3 col-xs-10 col-md-offset-1 gap-top">
                        <p class="text-center"><a href="<?php echo e(route('change-password')); ?>"><?php echo e(__('_user_account_settings.change_pass')); ?></a></p>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('bottom_scripts'); ?>
    <script>
        $('#region_id').on('change', function()
        {
           $.ajax({
            type: 'get',
            url: "<?php echo e(route('get-region-cities')); ?>",
            data: {region_id: $(this).val()},
            success: function(response)
            {
                response = JSON.parse(response);
                // console.log(response.content.length);
                if(response.content.length > 0)
                {
                    $('#city_id').html('');

                    for(var i = 0; i < response.content.length; i++)
                    {
                        var id   = response.content[i].id;
                        var name = response.content[i].name;

                        var option = '<option value="'+id+'">'+name+'</option>';

                        $('#city_id').append(option);
                    }
                }
            }
           }); 
        });
//        var subscribe_checkbox = $('#newsletter-subscribe');
//
//        $(document).ready(function()
//        {
//            subscribe_checkbox.change(function()
//            {
//                switch($(this).is(':checked'))
//                {
//                    case true:
//                        break;
//                    case false:
//                        break;
//                }
//            });
//        });

//        document.getElementById("district").selectedIndex = -1;
//        document.getElementById("country").selectedIndex = -1;
//        document.getElementById("city").selectedIndex = -1;
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>