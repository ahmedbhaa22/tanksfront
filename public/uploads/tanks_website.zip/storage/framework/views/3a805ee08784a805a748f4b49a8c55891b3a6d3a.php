<?php $footer = Helpers::getFooter(); ?>
<div class="bottom-footer">
        <div class="container">
            <div class="col-md-4">
                <div class="row">
                    <div class="col-xs-4 no-padding">
                        <img src="<?php echo e(asset('public/img/logo.png')); ?>" class="full-width" />
                    </div>
                </div>
                <div class="col-xs-12 no-padding">
                    <p>
                        <?php echo e($footer['name']); ?>

                    </p>
                </div>
            </div>
            <div class="col-md-4 col-sm-6  contact-footer-section">
                <b class="uppercase"><?php echo e(__('_footer.contact_us')); ?></b>
                <hr/>
                <?php $__currentLoopData = $footer['emails']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $email): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div>
                        <i class="fa fa-envelope"></i>
                        <a href="mailto:<?php echo e($email); ?>"><?php echo e($email); ?></a>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php $__currentLoopData = $footer['mobiles']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mobile): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div>
                        <i class="fa fa-phone"></i>
                        <a href="tel:<?php echo e($mobile); ?>"><?php echo e($mobile); ?></a>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php $__currentLoopData = $footer['addresses']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $address): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div>
                        <i class="fa fa-map-marker"></i><?php echo e($address); ?>

                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php $__currentLoopData = $footer['faxes']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fax): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div>
                        <i class="fa fa-fax"></i> <?php echo e($fax); ?>

                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="col-md-4 col-sm-6  links-footer-section">
                <b class="uppercase"><?php echo e(__('_footer.links')); ?></b>
                <hr/>

                
                
                

                
                
                

                
                
                

                <div class="col-md-6">
                    <a href="<?php echo e(url('maintainance')); ?>"><?php echo e(__('_footer.maintenance')); ?></a>
                </div>

                
                
                
                
                
                
                

                
                
                
                <div class="col-md-6">
                    <a href="<?php echo e(url('branches')); ?>"><?php echo e(__('_footer.branches')); ?></a>
                </div>

            </div>
            <div class="clearfix"></div>
            <hr/>
        </div>

        <div class="container">
            <div class="col-md-8">
                <?php echo e(__('_footer.copy_right')); ?> © <?php echo e(date('Y')); ?>

                <a href="<?php echo e(url('/')); ?>"><?php echo e(__('_footer.arabian_tanks')); ?> - </a><?php echo e(__('_footer.all_rights')); ?>

            </div>
            <div class="col-md-4 no-padding">
                    <span>
          						<a href="#" class=""><i class="fa fa-facebook-square"></i></a>
          						<a href="#" class=""><i class="fa fa-twitter-square "></i></a>
          						<a href="#" class=" "><i class="fa fa-instagram"></i></a>
          						<a href="#" class=""><i class="fa fa-linkedin"></i></a>
          					</span>
            </div>
        </div>
    </div>