<div class="col-md-8 col-sm-8 no-padding">
    <div class="offers-swiper">
        <!-- Swiper -->
        <div class="swiper-container">
            <div class="swiper-wrapper">

                <?php if($offers): ?>
                    <?php $__currentLoopData = $offers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $offer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="swiper-slide">
                            <div class="col-xs-12 no-padding">
                                <a href="<?php echo e(url('store/offer-details/'.$offer['id'].'/'.Helpers::str2url($offer['name']))); ?>">
                                    <div class="offer-div full-height" style="background-image:url(<?php echo e($offer['image']); ?>)">
                                                    <span class="offer-bar">
                                                <p><?php echo e($offer['name']); ?></p>
                                            </span>
                                    </div>
                                </a>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </div>
            <div class="swiper-button-next"></div>
            <div class="swiper-button-prev"></div>
        </div>
    </div>
</div>
<div class="col-md-4 col-sm-4 no-padding">
    <div class="ads-swiper swiper-container">
        <div class="swiper-wrapper">
            <?php if($ads): ?>
                <?php $__currentLoopData = $ads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a class="swiper-slide " href="<?php echo e(Helpers::getCmsModuleDataItemFromGroup($ad, 'keyvalue', 'link')); ?>" target="_blank">
                        <div class="ads-div full-height" alt="<?php echo e($ad['name']); ?>" style="background-image:url(<?php echo e($ad['image']); ?>)">
                        </div>
                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </div>
    </div>
</div>