<div class="carousel slide article-slide" id="article-photo-carousel">
    <div class="col-xs-9">
        <!-- Wrapper for slides -->
        <div class="carousel-inner cont-slider">
            <div class="item active">
                <img alt="" title="" class="no-padding" src="<?php echo e($product['image']); ?>">
            </div>
            <?php if(count($product['media'])): ?>
                <?php $__currentLoopData = $product['media']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $media): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($media['type'] == 'Img'): ?>
                        <div class="item">
                            <img alt="" title="" class="no-padding" src="<?php echo e($media['image']); ?>">
                        </div>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </div>
    </div>
    <div class="col-xs-3">
        <!-- Indicators -->
        <ol class="carousel-indicators">
            <li class="active" data-slide-to="0" data-target="#article-photo-carousel">
                <img alt="" src="<?php echo e($product['image']); ?>">
            </li>
            <?php if(count($product['media'])): ?>
                <?php $__currentLoopData = $product['media']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $media): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($media['type'] == 'Img'): ?>
                        <li data-slide-to="<?php echo e($key); ?>" data-target="#article-photo-carousel">
                            <img alt="" src="<?php echo e($media['image']); ?>">
                        </li>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </ol>
    </div>
</div>