<?php $__env->startSection('title', "Branches"); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid no-padding page-body">
    <div class="container">

        <?php echo e(Breadcrumbs::render('branches')); ?>


        <div class="col-xs-12 no-padding">
            <h4 class="main-title uppercase">
                <?php echo e(__('_site_branches.branches')); ?>

            </h4>
            <div class='container'>

                <div class="col-md-5">
                    <div class="form-group">
                        <label for="district"><?php echo e(__('_site_branches.choose_region')); ?></label>

                        <select class="form-control" id="district">
                            <option value=""><?php echo e(__('_site_branches.all_regions')); ?></option>
                            <?php $__currentLoopData = Helpers::getRegions(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $region): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($region['id']); ?>"><?php echo e($region['name']); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                <div class="clearfix"></div>
                <div >
                    <!-- Indicators -->

                    <!-- Wrapper for slides -->
                    <div id="branches-block">



                    </div>

                </div>
            </div>

            <!-- -->
        </div>
        <div class="clearfix"></div>
    </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('bottom_scripts'); ?>
    <script>
        $(document).ready(function () {
            getBranches();
            $("#district").change(function () {
                getBranches();
            });
        });

        function getBranches()
        {
            $("#branches-block").html('');
            $.ajax({
                url: '<?php echo e(url('branches')); ?>',
                data: {region_id: $('#district').val()},
                type: "GET",
                success: function (res) {
                    if(res) {
                        $("#branches-block").html(res);
                    }
                },
                error: function () {
                    console.log("ajax error");
                }
            });
        }
    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>