<?php $__env->startSection('title', "Login"); ?>

<?php $__env->startSection('content'); ?>

    <div class="container-fluid no-padding page-body">
        <div class="container">


            <div class="container">
                <h3 class="main-title uppercase text-center">
                    <?php echo e(__('_user_orders.payment_receipt')); ?>

                </h3>
                <div class="clear-fix"></div>

                <?php echo $__env->make('partials._formMessages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                <form method="post" action="<?php echo e(action('UserController@addPurchaseProve')); ?>"class="bordered col-md-6 col-md-offset-3 col-xs-10 col-md-offset-1" enctype="multipart/form-data">
                    <?php echo e(csrf_field()); ?>

                    <div class="form-group float-label-control">

                        <div class="clear-fix"></div>
                        <input name="payment_receipt" type="file" class="form-control" required>
                    </div>
                    <input type="hidden" name="order_id" value="<?php echo $order_id?>" />
                    <div class="col-md-6 col-md-offset-3 col-xs-10 col-md-offset-1">
                        <input type="submit" value="Save">
                    </div>
                  </form>

            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>