<?php $__env->startSection('title', "Store | Compare Products"); ?>

<?php $__env->startSection('content'); ?>

    <div class="container-fluid no-padding page-body">
        <div class="container">

            <?php echo e(Breadcrumbs::render('compare-product')); ?>


            <div class="container">
                <h3 class="main-title uppercase text-center">
                    <?php echo e(__('_store_compare.compare_products')); ?>

                </h3>
                <div class="col-xs-12">
                    <div class="table-responsive">
                        <table class="table table-bordered ">
                            <tbody>
                            <tr>
                                <th></th>
                                <?php $__currentLoopData = $productData['images']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <td>
                                        <div class="product-list-img-div">
                                            <div class="product-list-img" style="background-image:url('<?php echo e($image); ?>')"></div>
                                        </div>
                                    </td>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tr>
                            <tr>
                                <th><?php echo e(__('_store_compare.name')); ?></th>
                                <?php $__currentLoopData = $productData['names']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $names): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <td><?php echo e($names); ?></td>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tr>
                            <tr>
                                <th><?php echo e(__('_store_compare.description')); ?></th>
                                <?php $__currentLoopData = $productData['descs']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $desc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <td>
                                        <?php echo e($desc); ?>

                                    </td>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tr>
                            <tr>
                                <th><?php echo e(__('_store_compare.delivery')); ?></th>
                                <?php $__currentLoopData = $productData['deliveries']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $date): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <td><?php echo e($date); ?></td>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tr>
                            <tr>
                                <th><?php echo e(__('_store_compare.factory')); ?></th>
                                <?php $__currentLoopData = $productData['manufacturers']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $manufacturer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <td><?php echo e($manufacturer); ?></td>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tr>
                            <tr>
                                <th><?php echo e(__('_store_compare.price')); ?></th>
                                <?php $__currentLoopData = $productData['prices']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $price): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <td><?php echo e($price); ?></td>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tr>
                            <tr>
                                <th><?php echo e(__('_store_compare.avail_colors')); ?></th>
                                    <td>
                                        <?php if($productData['colors']): ?>
                                            <?php $__currentLoopData = $productData['colors']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $color): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php $__currentLoopData = $color; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php echo e($item['value_title'].($loop->last?"":" - ")); ?>

                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    </td>

                            </tr>
                            <tr>
                                <th><?php echo e(__('_store_compare.delivery_places')); ?></th>
                                <?php $__currentLoopData = $productData['delivery_places']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $place): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <td><?php echo e($place[1]['value']??""); ?></td>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tr>
                            <tr>
                                <th></th>
                                <?php $__currentLoopData = $productData['ids']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $id): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <td>
                                        <a href="<?php echo e(url('store/product-details/'.$id.'/'.Helpers::str2url($productData['names'][$key]))); ?>" class="btn btn-primary btn-sm add-to-cart" title="add to cart">
                                            <i class="fa fa-shopping-bag"></i>
                                        </a>
                                        <a href="#"class="btn btn-danger btn-sm gap-left clear-product" data-id="<?php echo e($id); ?>" title="remove">
                                            <i class="fa fa-trash"></i>
                                        </a>
                                    </td>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php echo $__env->make('partials._modals', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('bottom_scripts'); ?>
    <?php echo Html::script('public/js/functions.js'); ?>

    <script>
        $(".clear-product").on("click", function(e) {
            e.preventDefault();
            e.stopPropagation();
            var item = $(this);
            remove_compared(item.attr('data-id'), '<?php echo e(csrf_token()); ?>');
            var colnum = item.closest("td").prevAll("td").length;

            item.closest("table").find("tr").find("td:eq(" + colnum + ")").remove();

            return false;
        });

        $.fn.stars = function () {
            return $(this).each(function () {
                var rating = $(this).data("rating");
                var numStars = $(this).data("numStars");
                var fullStar = new Array(Math.floor(rating + 1)).join('<i class="fa fa-star"></i>');
                var halfStar = ((rating % 1) !== 0) ? '<i class="fa fa-star-half-empty"></i>' : '';
                var noStar = new Array(Math.floor(numStars + 1 - rating)).join('<i class="fa fa-star-o"></i>');
                $(this).html(fullStar + halfStar + noStar);
            });
        }
        $('.stars').stars();
    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>