<nav class="navbar  navbar-fixed-top">
    <div class="text-center upper-nav">

        <div class="container">
            <div class="row">
                <div class="col-md-2 col-xs-12">
                    <a href="<?php echo e(url('/')); ?>"><img class="logo col-xs-12" src="<?php echo e(asset('public/img/logo.png')); ?>" /></a>
                </div>
                <div class="col-md-8 col-sm-10 col-xs-9 search ">
                    <form action="<?php echo e(route('search')); ?>" method="get" enctype="multipart/form-data">
                        <!-- <?php echo e(csrf_field()); ?> -->
                        <input value="" name="keyword" type="search" placeholder="<?php echo e(__('_header.search')); ?>" />
                        <button type="submit" class="btn btn-default">
                            <i class="fa fa-search"></i>
                        </button>
                        
                            
                        

                    </form>
                </div>
                <div class="col-sm-2 col-xs-3 header-cart">
                    <a href="<?php echo e(url('store/shopping-cart')); ?>" title="shopping cart" id="cart_link">
                        <div class="col-xs-8 no-padding remove--screen">
                            <label for="cart_items" class="cart_text"><?php echo e(__('_header.cart')); ?></label>
                            <?php if(Session::get('loggedIn') == true): ?>
                                <div id="cart_items">
                                    <!-- <?php if(\Session::get('cart_count') > 0 ): ?>
                                        <span id="item_count"><?php echo e(\Session::get('cart_count')); ?></span><span> منتجات</span>
                                    <?php endif; ?> -->
                                        <span id="item_count"><?php echo e(Helpers::getCartCount()); ?></span><span> <?php echo e(__('_header.cart_products')); ?></span>
                                </div>
                            <?php endif; ?>
                        </div>

                        <div class="col-sm-4 col-xs-12 no-padding">
                            <i class="fa fa-shopping-bag"><?php if(Session::get('loggedIn') == true): ?> <span class="badge badge-default"> <?php echo e(Helpers::getCartCount()); ?> </span> <?php endif; ?></i>
                        </div>
                    </a>
                </div>
            </div>
        </div>
        <div id="main-navbar" class="main-navbar ">
            <div class="container">
                <div class="navbar-header pull-right">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                </div>
                <div class="collapse navbar-collapse" id="myNavbar">
                    <ul class="nav navbar-nav">
                        <li class="<?php echo e(Request::is("/")?'active':''); ?>"><a href="<?php echo e(url('/')); ?>"><?php echo e(__('_header.home')); ?></a></li>
                        <li class="<?php echo e(Request::is("store")?'active':''); ?>"><a href="<?php echo e(url('store')); ?>"><?php echo e(__('_header.store')); ?></a></li>
                        <li class="dropdown">
                            <a class="dropdown-toggle" data-toggle="dropdown" href="#"> <?php echo e(__('_header.products')); ?>

                                <span class="caret"></span></a>
                                <ul class="dropdown-menu">
                                    <?php if(Helpers::getCategoryTree()): ?>
                                        <?php $__currentLoopData = Helpers::getCategoryTree(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if(count($cat['children'])): ?>
                                                <li class="dropdown-submenu"><a href="<?php echo e(url('product-category/'.$cat['parent_id'].'/'.Helpers::str2url($cat['parent_name']))); ?>"> <?php echo e($cat['parent_name']); ?></a>
                                                    <ul class="dropdown-menu">
                                                        <?php $__currentLoopData = $cat['children']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <li><a href="<?php echo e(url('product-category/'.$child['childe_id'].'/'.Helpers::str2url($child['child_name']))); ?>"><?php echo e($child['child_name']); ?></a></li>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </ul>
                                            <?php else: ?>
                                                <li><a href="<?php echo e(url('product-category/'.$cat['parent_id'].'/'.Helpers::str2url($cat['parent_name']))); ?>"><?php echo e($cat['parent_name']); ?></a></li>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </ul>
                        </li>
                        
                        
                        

                        
                        
                        

                        
                        
                        
                        <li class="<?php echo e(Request::is("contact-us")?'active':''); ?>"><a href="<?php echo e(url('contact-us')); ?>"><?php echo e(__('_header.contact_us')); ?></a></li>

                        
                        
                        
                    </ul>
                    <ul class="nav navbar-nav navbar-right">
                        <?php if(Session::get('loggedIn') == true): ?>
                            <li class="icon">
                                <a href="<?php echo e(route('wish-list')); ?>" title="wishlist">
                                    <i class="fa fa-heart-o"></i>
                                   <!-- <?php if(Session::get('wishlist_count') > 0 ): ?>
                                        <span class="badge badge-default"> <?php echo e(Session::get('wishlist_count')); ?> </span>
                                    <?php endif; ?> -->
                                    <span class="badge badge-default"> <?php echo e(Helpers::getWishlistCount()); ?> </span>
                                </a>
                            </li>
                            <li class="icon">
                                <a href="<?php echo e(route('compare-product')); ?>" title="compare">
                                    <i class="fa fa-exchange"></i>
                                </a>
                            </li>
                            <li class="dropdown dropdown-user">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown" data-hover="dropdown"
                                   data-close-others="true">
                                    <?php if(Session::has('Img') && Session::get('Img') != ''): ?>
                                        <img alt="" class="img-circle" src="<?php echo e(config('app.api_endpoints.backend_url') . Session::get('Img')); ?>">
                                    <?php else: ?>
                                        <img alt="" class="img-circle" src="<?php echo e(asset('public/img/default-avatar.jpg')); ?>">
                                    <?php endif; ?>
                                </a>
                                <ul class="dropdown-menu dropdown-menu-default">
                                    <li>
                                        <a href="<?php echo e(route('user-orders')); ?>"><?php echo e(__('_header.my_orders')); ?></a>
                                    </li>
                                    <li class="divider"></li>
                                    <li>
                                        <a href="<?php echo e(route('shipping-addresses')); ?>"><?php echo e(__('_header.shipping_addresses')); ?></a>
                                    </li>
                                    <li class="divider"></li>
                                    <li>
                                        <a href="<?php echo e(route('account-settings')); ?>"><?php echo e(__('_header.account_settings')); ?></a>
                                    </li>
                                    <li>
                                        <a href="<?php echo e(route('logout')); ?>">
                                            <button class="btn btn-default btn-outline-custom btn-orange"><?php echo e(__('_header.logout')); ?></button>
                                        </a>
                                    </li>
                                </ul>
                            </li>
                        <?php else: ?>
                            <li class="icon">
                                <a href="<?php echo e(url('login')); ?>">
                                   <?php echo e(__('_header.login')); ?>

                                </a>
                            </li>
                        <?php endif; ?>
                        <li>
                            <?php if(App::isLocale('en')): ?>
                                <a href="<?php echo e(route('locale.switch', 'ar')); ?>" class="">
                                    العربية
                                </a>
                            <?php else: ?>
                                <a href="<?php echo e(route('locale.switch', 'en')); ?>" class="">
                                    English
                                </a>
                            <?php endif; ?>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</nav>