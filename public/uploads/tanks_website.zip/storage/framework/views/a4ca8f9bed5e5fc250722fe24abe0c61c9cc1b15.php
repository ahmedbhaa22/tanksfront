
    
    
    
    


<?php if(Session::has('success')): ?>
    <div class="alert alert-success alert-dismissable">
        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
        <span><?php echo e(Session::get('success')['message']); ?></span>
    </div>
<?php endif; ?>