<?php $__env->startSection('title', "Store | Wish List"); ?>

<?php $__env->startSection('content'); ?>

    <div class="container-fluid no-padding page-body">
        <div class="container">

            <?php echo e(Breadcrumbs::render('wish-list')); ?>


            <div class="container">
                <h3 class="main-title uppercase">
                    <?php echo e(__('_store_wishlist.wishlist')); ?>

                </h3>

                <!-- Show Products -->
                <?php if($products): ?>
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="bordred-div not-curved clearfix wish-list" id="wish-list-<?php echo e($key); ?>">
                            <div class="col-md-2 col-sm-4 col-xs-6 product-list-img"
                                 style="background-image:url(<?php echo e($product['image']); ?>)"></div>
                            <div class="col-md-5 col-sm-4 col-xs-6 ">
                                <b class="uppercase"><?php echo e($product['name']); ?></b><br/>
                                <?php if(Helpers::getProductDataItemFromGroup($product, 'extra', 'discount_percent')!=''): ?>
                                    <span><span class="pram-title"><?php echo e(__('_store_wishlist.discount_percent')); ?></span> <?php echo e(Helpers::getProductDataItemFromGroup($product, 'extra', 'discount_percent')); ?></span><br/>
                                <?php endif; ?>
                                <span><span class="pram-title"><?php echo e(__('_store_wishlist.price')); ?></span> <?php echo e(Helpers::getProductDataItemFromGroup($product, 'extra', 'price')); ?></span><br/>
                                <span><span class="pram-title"><?php echo e(__('_store_wishlist.factory')); ?></span> <?php echo e(Helpers::getManufacturer($product)); ?></span>
                            </div>
                            <div class="col-md-5 col-sm-4 col-xs-12">
                                <a href="#" class="btn btn-danger clear-product  btn-md pull-right" title="remove"
                                   onclick="document.getElementById('wish-list-<?php echo e($key); ?>').style.display = 'none'"><i
                                            class="fa fa-trash"></i></a>
                                <a href="<?php echo e(url('store/product-details/'.$product['id'].'/'.Helpers::str2url($product['name']))); ?>" class="btn btn-success add-to-cart btn-md pull-right"
                                   title="add to cart" data-id="<?php echo e($product['id']); ?>"><i class="fa fa-shopping-bag"></i></a>
                                <a href="#" class="btn btn-primary btn-md pull-right compare-product" data-id="<?php echo e($product['id']); ?>" title="compare"><i
                                            class="fa fa-exchange"></i></a>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <div class="col-xs-4 col-xs-offset-4">
                    <a href="#" class="btn form-submit-btn btn-outline-custom  btn-blue col-xs-12 no-padding"><i
                                class="fa fa-trash"></i><?php echo e(__('_store_wishlist.remove_wishlist')); ?></a>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <?php echo $__env->make('partials._modals', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('bottom_scripts'); ?>

    <script>
        document.getElementById("district").selectedIndex = -1;
        document.getElementById("country").selectedIndex = -1;
        document.getElementById("city").selectedIndex = -1;
    </script>

    <?php echo Html::script('public/js/functions.js'); ?>

    <script>
        $(document).ready(function() {
            $(".compare-product").on("click", function(e) {
                e.preventDefault();
                e.stopPropagation();
                var item = $(this);
                compare_product(item.attr('data-id'), '<?php echo e(csrf_token()); ?>');
                return false;
            });
        });
    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>