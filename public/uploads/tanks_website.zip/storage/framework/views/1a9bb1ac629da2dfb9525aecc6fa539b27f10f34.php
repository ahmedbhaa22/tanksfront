<?php $__env->startSection('title', "Store | Offers"); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid no-padding page-body">
    <div class="container product-details-page">

        <?php echo e(Breadcrumbs::render('offers')); ?>


        <div class="container">
            <h3 class="main-title uppercase">
                <?php echo e(__('_store_offers.offers')); ?>

            </h3>
            <div class="col-md-12 sec-nav">
                <div class="form-group">
                    <label class="col-xs-3" for="district"><?php echo e(__('_store_offers.choose_region')); ?></label>
                    <div class="col-xs-9">
                        <select class="form-control" id="district-dropdown">
                            <option value=""><?php echo e(__('_store_offers.all_regions')); ?></option>
                            <?php $__currentLoopData = $regions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $region): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($region['id']); ?>"><?php echo e($region['name']); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
            </div>
            <div class="col-xs-12 offers gap no-padding" id="offers-block">

            </div>
        </div>
    </div>
    </div>
    <?php echo $__env->make('partials._modals', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('bottom_scripts'); ?>

    <?php echo Html::script('public/js/functions.js'); ?>


    <script>
        $(document).ready(function () {
            get_offers_by_region($("#district-dropdown").val());
            $("#district-dropdown").change(function () {
                get_offers_by_region($(this).val());
            });
        });
    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>