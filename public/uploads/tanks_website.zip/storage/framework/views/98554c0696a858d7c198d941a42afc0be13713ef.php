<?php $__env->startSection('title', "Store | Offers | " . $offer['name']); ?>

<?php $__env->startSection('content'); ?>
    <div id="fb-root"></div>
    <script>(function(d, s, id) {
            var js, fjs = d.getElementsByTagName(s)[0];
            if (d.getElementById(id)) return;
            js = d.createElement(s); js.id = id;
            js.src = "//connect.facebook.net/en_GB/sdk.js#xfbml=1&version=v2.10";
            fjs.parentNode.insertBefore(js, fjs);
        }(document, 'script', 'facebook-jssdk'));</script>

    <div class="container-fluid no-padding page-body">
    <div class="container">

        <?php echo e(Breadcrumbs::render('offer-details', $offer)); ?>


        <?php echo $__env->make('partials._topCategories', ['categories' => $categories], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <?php if($tags): ?>
        <div class="col-xs-12">

                <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="#"><span class="label label-default"><?php echo e($value['name']); ?></span></a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
        <?php endif; ?>

        <div class="col-md-8 col-sm-9 no-padding">
            <div class="offer-div full-height" style="background-image:url(<?php echo e($offer['image']); ?>)">

            </div>
        </div>

        <div class="col-md-4 col-sm-3 no-padding product-details-col pro-middle-col">
            <h4 class="product-title uppercase col-md-7 no-padding">
               <?php echo e($offer['name']); ?>

            </h4>

            <div class="col-md-5 no-padding">

                <a class="btn offers-btn small-btn btn-block-blue pull-right no-padding add_to_wish_list" data-id="<?php echo e($offer['id']); ?>" href="#" title="Add to wishlist">
                    <i class="fa fa-heart-o" aria-hidden="true"></i>
                </a>
                <div class="fb-share-button pull-right" data-href="<?php echo e(route('offer-details', ['id' => $offer['id'], 'slug' => str_slug($offer['name'])])); ?>" data-layout="button_count" data-size="small" data-mobile-iframe="true"><a class="fb-xfbml-parse-ignore" target="_blank" href="https://www.facebook.com/sharer/sharer.php?u=<?php echo e(route('offer-details', ['id' => $offer['id'], 'slug' => str_slug($offer['name'])])); ?>&amp;src=sdkpreparse"><?php echo e(__('_store_offer_details.share')); ?></a></div>

            </div>

            <div class="col-md-12 no-padding"><?php echo e($offer['description']); ?></div>

            <div class="clearfix"></div>

            <div class="col-xs-12 gap no-padding">
                <div class="form-group ">
                    <label for="deliver-place "><?php echo e(__('_store_offer_details.delivery_place')); ?></label>
                    <select class="form-control bordered" name="deliver-place" id="deliver-place">
                        <?php if(!empty($deliveryPlaces)): ?>
                            <?php $__currentLoopData = $deliveryPlaces; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item[0]['value']); ?>"><?php echo e($item[1]['value']); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </select>
                </div>
            </div>
            <div class="clearfix "></div>
            <div class="price-container ">
                <p class="product-tag tag-flash-sale"> <i class="fa fa-star"></i><?php echo e(__('_store_offer_details.best_price')); ?></p>
                <p class="price">
                    
                    <span class="current-price"><strong><?php echo e(__('_store_offer_details.now')); ?> </strong><strong><?php echo e($newPrice); ?> <?php echo e(__('_store_offer_details.sr')); ?></strong></span>

                    <?php if($originalPrice && $newPrice): ?>
                        
                    <?php endif; ?>
                </p>
            </div>
            <div class="clearfix"></div>
            <button type="button" class="btn add-to-cart gap-left" data-id="<?php echo e($offer['id']); ?>"><i class="fa fa-shopping-bag"></i><?php echo e(__('_store_offer_details.add_to_cart')); ?></button>

            <b class="expire-date pull-right" style="direction: ltr">
            <?php if(in_array(1, $offerTypesIds) && in_array(2, $offerTypesIds)): ?>
                <?php echo e(date('d/m/Y', $offerEndDate)); ?><?php echo e(__('_store_offer_details.offer_to_date_or_qty')); ?>

            <?php elseif(in_array(1, $offerTypesIds) && !in_array(2, $offerTypesIds)): ?>
                    <?php echo e(__('_store_offer_details.offer_to_qty')); ?>

            <?php elseif(!in_array(1, $offerTypesIds) && in_array(2, $offerTypesIds)): ?>
                <?php echo e(date('d/m/Y', $offerEndDate)); ?><?php echo e(__('_store_offer_details.offer_to_date')); ?>

            <?php endif; ?>
</b>

        </div>
        <div class="clearfix"></div>

        <div class="row">
            <h3 class="col-xs-12"><?php echo e(__('_store_offer_details.offer_products')); ?></h3>

            <?php if($products): ?>
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-sm-6 col-xs-6 no-padding">
                        <div class="bordred-div not-curved clearfix shopping-cart-div">
                            <div class="col-sm-3 col-xs-12 product-list-img-div no-padding">
                                <div class="product-list-img" style="background-image:url(<?php echo e($product['image']); ?>)"></div>
                            </div>
                            <div class="col-sm-9 col-xs-12 product-details">
                                <b class="uppercase"><?php echo e($product['name']); ?></b><br/>
                                <span><span class="pram-title"><?php echo e(__('_store_offer_details.qty')); ?></span> 3</span><br/>
                                <span><span class="pram-title"><?php echo e(__('_store_offer_details.color')); ?></span> <?php echo e(Helpers::getProductKeyValueItemText($product, 'avaliable_colors_entity', true)); ?> </span><br/>
                                <span><span class="pram-title"><?php echo e(__('_store_offer_details.total_price')); ?></span> <?php echo e(Helpers::getProductDataItemFromGroup($product, 'extra', 'price')); ?></span>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>

            <div class="clearfix"></div>
            <div class="col-sm-12 ">
                <button type="button" class="btn add-to-cart" data-id="<?php echo e($offer['id']); ?>"><i class="fa fa-shopping-bag"></i><?php echo e(__('_store_offer_details.add_to_cart')); ?></button>
            </div>

        </div>
    </div>
</div>

    <?php echo $__env->make('partials._modals', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('bottom_scripts'); ?>
    <?php echo Html::script('public/js/functions.js'); ?>


    <script>
        $(document).ready(function() {
            $(".add-to-cart").on("click", function(e){
                e.preventDefault();
                e.stopPropagation();
                var item = $(this);
                add_to_cart(item.attr('data-id'), 2, 1, $("#deliver-place").val(), '<?php echo e(csrf_token()); ?>');
            });

            $(".add_to_wish_list").on("click", function(e) {
                e.preventDefault();
                e.stopPropagation();
                var item = $(this);
                add_to_wish_List(item.attr('data-id'), 2, '<?php echo e(csrf_token()); ?>');

                return false;
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>