<?php $__env->startSection('title', $category['name']); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid no-padding page-body">
<div class="container">

        <?php echo e(Breadcrumbs::render('product-category', $category)); ?>


        <?php if($childCats): ?>
            <nav class="navbar navbar-default sec-nav">
                <div class="container">
                    <ul class="nav navbar-nav">
                        <?php $__currentLoopData = $childCats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="uppercase"><a href="<?php echo e(url('product-category/'.$cat['childe_id'].'/'.Helpers::str2url($cat['child_name']))); ?>"><?php echo e($cat['child_name']); ?></a></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            </nav>
        <?php endif; ?>
        <div class="col-md-12 no-padding">
            <h4 class="uppercase main-title">
                <?php echo e($category['name']); ?>

                <span class="pull-right"></span>
            </h4>
        </div>

        <div class="col-sm-7">
            <h4><?php echo e($category['name']); ?></h4>

            <p>
                <?php echo html_entity_decode($category['description']); ?>

            </p>

            <img src="<?php echo e($category['image']); ?>" width="400" height="400" class="img-responsive">
        </div>

        <div class="col-sm-5">
            <?php echo $__env->make('partials._productMedia', ['product' => $category], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
        <div class="clearfix"></div> <br>
    <?php if($category['more']['attributes']): ?>
        <h4 class="uppercase main-title">
            <?php echo e(__('_site_category_product.products')); ?>

            <span class="pull-right"></span>
        </h4>

        <div  class="bordred-div product-details-table-div">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th scope="col" class="rgHeader" style="text-align:right;"><?php echo e(__('_site_category_product.product')); ?></th>
                        <?php $__currentLoopData = $category['more']['attributes']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attributeName): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <th scope="col" class="rgHeader" style="text-align:right;"><?php echo e($attributeName); ?></th>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tr>
                </thead>
                <tbody>

                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="rgAltRow" id="ctl00_MainContentPlaceHolder_ProductsDetails1_RepeaterMain_ctl00_RadGrid1_ctl00__1">
                                <td style="text-align: right;">
                                    <a href="<?php echo e(route('product-details', ['id' => $product['id'], 'slug' => Helpers::str2url($product['name'])])); ?>" class="btn"><?php echo e($product['name']); ?></a>
                                </td>

                                <?php $__currentLoopData = Helpers::getProductGroup($product, 'attributes'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attribute): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <td style="text-align: right;">
                                        <?php echo e($attribute['value']['value_title']??""); ?>

                                    </td>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <td style="width:50px;">
                                    <a href="<?php echo e(route('product-details', ['id' => $product['id'], 'slug' => Helpers::str2url($product['name'])])); ?>" class="btn add-to-cart "><?php echo e(__('_site_category_product.details')); ?></a>
                                </td>
                            </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>

            </table>
        </div>
            <?php endif; ?>
    </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>