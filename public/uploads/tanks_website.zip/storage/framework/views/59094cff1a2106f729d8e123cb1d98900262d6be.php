<?php $__env->startSection('title', "Register"); ?>

<?php $__env->startSection('content'); ?>

    <div class="container-fluid no-padding page-body">
        <div class="container">

            <?php echo e(Breadcrumbs::render('register')); ?>


            <div class="container">
                <h3 class="main-title uppercase text-center">
                    <?php echo e(__('_user_register.register')); ?>

                </h3>

                <?php echo $__env->make('partials._formMessages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                <form method="post" class="bordered  col-md-8 col-md-offset-2 col-xs-10 col-md-offset-1">
                    <?php echo e(csrf_field()); ?>

                    <div class="form-group  float-label-control">
                        <label for="email"><?php echo e(__('_user_register.email')); ?></label>
                        <span class="error-line text-danger"><?php echo e(__('_user_register.required')); ?></span>
                        <input type="email" class="form-control" name="email" id="email" value="<?php echo e(old('email')); ?>">
                    </div>
                    <div class="form-group  float-label-control">
                        <label for="username"><?php echo e(__('_user_register.username')); ?></label>
                        <span class="error-line text-danger"><?php echo e(__('_user_register.required')); ?></span>
                        <input type="text" class="form-control" name="username" id="username" value="<?php echo e(old('username')); ?>">
                    </div>
                    <div class="form-group  float-label-control">
                        <label for="password"><?php echo e(__('_user_register.password')); ?></label>
                        <span class="error-line text-danger"><?php echo e(__('_user_register.required')); ?></span>
                        <input type="password" class="form-control" name="password" id="password" autocomplete="false">
                    </div>
                    <div class="form-group  float-label-control">
                        <label for="confirm-password"><?php echo e(__('_user_register.re-pass')); ?></label>
                        <span class="error-line text-danger"><?php echo e(__('_user_register.required')); ?></span>
                        <input type="password" class="form-control" name="confirmPassword" id="confirm-password" autocomplete="false" >
                    </div>
                    <div class="form-group  float-label-control">
                        <label for="name"><?php echo e(__('_user_register.name')); ?></label>
                        <span class="error-line text-danger"><?php echo e(__('_user_register.required')); ?></span>
                        <input type="text" class="form-control" name="name" id="name" value="<?php echo e(old('name')); ?>">
                    </div>
                    <div class="form-group  float-label-control">
                        <label for="mobile"><?php echo e(__('_user_register.mobile')); ?></label>
                        <span class="error-line text-danger"><?php echo e(__('_user_register.required')); ?></span>
                        <input type="tel" class="form-control" name="mobile" id="mobile" value="<?php echo e(old('mobile')); ?>">
                    </div>
                    <button type="submit" class="btn form-submit-btn btn-outline-custom btn-blue col-xs-12"><?php echo e(__('_user_register.save')); ?></button>
                </form>
                <div class="col-md-6 col-md-offset-3 col-xs-10 col-md-offset-1">
                    <p class="text-center"><?php echo e(__('_user_register.have_account')); ?><a href="<?php echo e(url('login')); ?>"><?php echo e(__('_user_register.login')); ?></a></p>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('bottom_scripts'); ?>
    <script>
//        document.getElementById("district").selectedIndex = -1;
//        document.getElementById("country").selectedIndex = -1;
//        document.getElementById("city").selectedIndex = -1;

        $(".form-control").keyup(function () {
            if($(this).val() != '') {
                $(this).siblings(".error-line").hide();
            } else {
                $(this).siblings(".error-line").show();
            }
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>