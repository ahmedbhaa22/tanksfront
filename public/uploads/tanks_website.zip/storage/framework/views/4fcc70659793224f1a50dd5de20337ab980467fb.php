<?php $__env->startSection('title', "Store | Shopping Cart | Checkout"); ?>

<?php $__env->startSection('content'); ?>

    <div class="container-fluid no-padding page-body">
        <div class="container product-details-page">

            <?php echo e(Breadcrumbs::render('shopping-cart')); ?>


            <?php echo $__env->make('partials._formMessages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <div class="container">
                <?php if($products): ?>
                    <form method="post" enctype="multipart/form-data">
                        <?php echo e(csrf_field()); ?>

                        <div id="smartwizard">
                            <ul>
                                <li><a href="#step-1">1<br /><small><?php echo e(__('_store_shopping_cart.shopping_cart')); ?></small></a></li>
                                <li><a href="#step-2">2<br /><small><?php echo e(__('_store_shopping_cart.shipping_info')); ?></small></a></li>
                                <li><a href="#step-3">3<br /><small><?php echo e(__('_store_shopping_cart.payment_methods')); ?></small></a></li>
                                <li><a href="#step-4">4<br /><small><?php echo e(__('_store_shopping_cart.attach_receipt')); ?></small></a></li>
                            </ul>
                            <div>
                                <div id="step-1" class="">

                                    <h3 class="main-title uppercase">
                                        <?php echo e(__('_store_shopping_cart.shopping_cart')); ?>

                                    </h3>

                                        <?php
                                         $cart_final_price = 0;
                                         $all_products_prices = 0;
                                         $all_tax_amount = 0;
                                         $total_after_tax = 0;
                                        ?>



                                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                            <div class="col-md-6">
                                                <div class="bordred-div not-curved clearfix shopping-cart-div" id="shopping-cart-div-<?php echo e($key); ?>">
                                                    <div class="col-sm-2 col-xs-6 products-list-img-div no-padding">
                                                        <div class="products-list-img full-width" style="background-image:url('<?php echo e($product['image']); ?>');"></div>
                                                    </div>
                                                    <div class="col-sm-6 col-xs-6 product-details">
                                                        <b class="uppercase"><?php echo e($product['name']); ?></b>
                                                        <?php if(Helpers::getProductDataItemFromGroup($product, 'extra', 'discount_percent')!=''): ?>
                                                            <span class="text-danger"> ( <?php echo e(Helpers::getProductDataItemFromGroup($product, 'extra', 'discount_percent')); ?> (<?php echo e(__('_store_shopping_cart.discount')); ?></span><br/>
                                                        <?php endif; ?>
                                                        <span class="col-xs-12 no-padding"><span class="pram-title"><?php echo e(__('_store_shopping_cart.price')); ?></span> <?php echo e(Helpers::getProductDataItemFromGroup($product, 'extra', 'price')); ?></span><br/>
                                                        <span class="col-xs-12 no-padding"><span class="pram-title"><?php echo e(__('_store_shopping_cart.tax_percent')); ?></span> <?php echo e(Helpers::getProductDataItemFromGroup($product, 'extra', 'tax_percent')); ?>&nbsp%</span><br/>
                                                        <span class="col-xs-12 no-padding"><span class="pram-title"><?php echo e(__('_store_shopping_cart.factory')); ?></span> <?php echo e(Helpers::getManufacturer($product)); ?></span><br/>
                                                        <span class="col-xs-12 no-padding"><span class="pram-title"><?php echo e(__('_store_shopping_cart.qty')); ?></span><?php echo e(Helpers::getCount($product)); ?></span>
                                                    </div>
                                                    <div class="col-sm-4 col-xs-12">
                                                        <p class="text-primary pull-right"><span><?php echo e(__('_store_shopping_cart.total_price')); ?></span>
                                                            <?php
                                                                $all_products_prices += Helpers::getProductDataItemFromGroup($product, 'extra', 'price');
                                                                $price_total = Helpers::getProductDataItemFromGroup($product, 'extra', 'price');
                                                                $all_tax_amount += $price_total * (Helpers::getProductDataItemFromGroup($product, 'extra', 'tax_percent') / 100);
                                                                // $price_total = $price_total + ($price_total * (Helpers::getProductDataItemFromGroup($product, 'extra', 'tax_percent') / 100));

                                                                if(Helpers::getProductDataItemFromGroup($product, 'extra', 'discount_percent')!='')
                                                                    {
                                                                $price_total = $price_total - ($price_total * (Helpers::getProductDataItemFromGroup($product, 'extra', 'discount_percent') / 100));
                                                                }
                                                            ?>
                                                         <?php echo e($price_total * Helpers::getCount($product)); ?></p>

                                                        <div class="clearfix"></div>
                                                        <a href="javascript:void(0)" class="btn btn-danger clear-product btn-md pull-right remove-from-cart" data-id="<?php echo e($product['id']); ?>" data-item-id="<?php echo e(Helpers::getItemType($product)); ?>" title="remove"><i class="fa fa-trash"></i></a>
                                                        <a href="#" class="btn btn-primary add-to-cart btn-md pull-right compare-product" data-id="<?php echo e($product['id']); ?>" title="compare"><i class="fa fa-exchange"></i></a>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php
                                            $total_after_tax = $all_products_prices + $all_tax_amount;
                                        ?>


                                    <div class="clearfix"></div>
                                    <div class="col-xs-12">
                                        
                                        
                                        

                                        <div class="bordred-div not-curved clearfix">
                                            <div class="bordred-div not-curved clearfix">
                                                <div class="row">
                                                    <div class="col-xs-6 ">
                                                        <b><?php echo e(__('_store_shopping_cart.sum')); ?></b>
                                                    </div>
                                                    <div class="col-xs-6">
                                                        <span class="pull-right"><?php echo e($extraData['price']); ?></span>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col-xs-6 ">
                                                        <b><?php echo e(__('_store_shopping_cart.all_tax')); ?></b>
                                                    </div>
                                                    <div class="col-xs-6">
                                                        <span class="pull-right"><?php echo e($extraData['tax_amount']); ?></span>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col-xs-6 ">
                                                        <b><?php echo e(__('_store_shopping_cart.discount')); ?></b>
                                                    </div>
                                                    <div class="col-xs-6">
                                                        <span class="pull-right"><?php echo e($extraData['discount_amount']); ?></span>
                                                    </div>
                                                </div>
                                                
                                                
                                                
                                                <hr/>
                                                <div class="row">
                                                    <div class="col-xs-6 ">
                                                        <b><?php echo e(__('_store_shopping_cart.total')); ?></b>
                                                    </div>
                                                    <div class="col-xs-6">
                                                        <span class="pull-right"><?php echo e($extraData['total_price']); ?></span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                         

                                    </div>
                                    <div class="clearfix"></div>
                                </div>

                                <div id="step-2" class="">

                                    <div class="col-md-8">
                                        <h4 class="main-title uppercase col-xs-12 "><?php echo e(__('_store_shopping_cart.shipping_addresses')); ?></h4>
                                        <div class="clearfix"></div>

                                        <?php if($extraData['user_address']): ?>
                                            <div class="bordred-div not-curved clearfix addresses-list">
                                                <div class="col-sm-1 col-xs-2">
                                                    <input type="checkbox" id="check1" name="shippingAddress" value="<?php echo e($extraData['user_address']['id']); ?>" checked disabled>
                                                    <label for="check1"></label>
                                                </div>
                                                <div class="col-sm-3 col-xs-10">
                                                    <b class="uppercase"><?php echo e($extraData['user_address']['details']); ?></b>
                                                </div>
                                                <div class="col-sm-8 col-xs-12">
                                                    <span><?php echo e($extraData['user_address']['details']); ?></span>
                                                </div>
                                            </div>
                                            <div class="col-md-3 col-sm-6  col-xs-10 pull-right">
                                                <a href="<?php echo e(route('shipping-addresses')); ?>" target="_blank" class="btn form-submit-btn btn-outline-custom  btn-blue  col-xs-12 no-padding"><?php echo e(__('_store_shopping_cart.change_address')); ?></a>
                                            </div>
                                        <?php endif; ?>

                                        <h4 class="main-title uppercase col-xs-12"><?php echo e(__('_store_shopping_cart.leave_comment')); ?></h4>
                                        <div class="clearfix"></div>

                                        <div class="clearfix">
                                            <div class="col-xs-12 form-group  float-label-control">
                                                <label for="info"><?php echo e(__('_store_shopping_cart.shipping_time_info')); ?></label>
                                                <input type="text" class="form-control" id="info" name="userComment">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <h4 class="main-title uppercase gap-left"><?php echo e(__('_store_shopping_cart.order_details')); ?></h4>
                                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="col-xs-12 no-padding">
                                                <div class="bordred-div not-curved clearfix shopping-cart-div">
                                                    <div class="col-sm-3 col-xs-12 product-list-img-div no-padding">
                                                        <div class="product-list-img" style="background-image:url('<?php echo e($product['image']); ?>');"></div>
                                                    </div>
                                                    <div class="col-sm-9 col-xs-12 product-details">
                                                        <b class="uppercase"><?php echo e($product['name']); ?></b><br/>
                                                        <span class="col-xs-12 no-padding"><span class="pram-title"><?php echo e(__('_store_shopping_cart.qty')); ?></span> 3</span><br/>
                                                        <span class="col-xs-12 no-padding"><span class="pram-title"><?php echo e(__('_store_shopping_cart.color')); ?></span> <?php echo e(Helpers::getProductKeyValueItemText($product, 'avaliable_colors_entity', true)); ?></span><br/>
                                                        <span class="col-xs-12 no-padding"><span class="pram-title"><?php echo e(__('_store_shopping_cart.total_price')); ?></span> <?php echo e(Helpers::getProductDataItemFromGroup($product, 'extra', 'price')); ?></span><br/>
                                                        <span class="col-xs-12 no-padding"><span class="pram-title"><?php echo e(__('_store_shopping_cart.tax_percent')); ?></span> <?php echo e(Helpers::getProductDataItemFromGroup($product, 'extra', 'tax_percent')); ?>&nbsp%</span>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        <div class="col-xs-12 no-padding">
                                            <div class="bordred-div not-curved clearfix">
                                                <div class="row">
                                                    <div class="col-xs-6 ">
                                                        <b><?php echo e(__('_store_shopping_cart.sum')); ?></b>
                                                    </div>
                                                    <div class="col-xs-6">
                                                        <span class="pull-right"><?php echo e($extraData['price']); ?></span>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                <div class="col-xs-6 ">
                                                    <b><?php echo e(__('_store_shopping_cart.all_tax')); ?></b>
                                                </div>
                                                <div class="col-xs-6">
                                                    <span class="pull-right"><?php echo e($extraData['tax_amount']); ?></span>
                                                </div>
                                            </div>
                                                <div class="row">
                                                    <div class="col-xs-6 ">
                                                        <b><?php echo e(__('_store_shopping_cart.discount')); ?></b>
                                                    </div>
                                                    <div class="col-xs-6">
                                                        <span class="pull-right"><?php echo e($extraData['discount_amount']); ?></span>
                                                    </div>
                                                </div>
                                                
                                                
                                                
                                                <hr/>
                                                <div class="row">
                                                    <div class="col-xs-6 ">
                                                        <b><?php echo e(__('_store_shopping_cart.total')); ?></b>
                                                    </div>
                                                    <div class="col-xs-6">
                                                        <span class="pull-right"><?php echo e($extraData['total_price']); ?></span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="clearfix"></div>
                                </div>

                                <div id="step-3" class="">

                                    <h4 class="main-title uppercase col-xs-12 "><?php echo e(__('_store_shopping_cart.payment_method')); ?></h4>
                                    <div class="clearfix"></div>
                                    <table class="table table-striped table-bordered">
                                        <thead>
                                        <tr>
                                            <th>ا<?php echo e(__('_store_shopping_cart.bank_name')); ?></th>
                                            <th><?php echo e(__('_store_shopping_cart.IBAN_no')); ?></th>
                                            <th><?php echo e(__('_store_shopping_cart.acc_name')); ?></th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                            <?php if($extraData['payment_methods']): ?>
                                                <?php $__currentLoopData = $extraData['payment_methods']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $method): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <td><?php echo e($method['bank_name']); ?></td>
                                                        <td><?php echo e($method['account_number']); ?></td>
                                                        <td><?php echo e($method['account_name']); ?></td>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>
                                        </tbody>
                                    </table>
                                    <p><?php echo e(__('_store_shopping_cart.please_attach')); ?></p>
                                    <div class="clearfix"></div>
                                </div>

                                <div id="step-4" class="">
                                    <h4 class="main-title uppercase col-xs-12 "><?php echo e(__('_store_shopping_cart.attach_receipt')); ?></h4>
                                    <p><?php echo e(__('_store_shopping_cart.please_attach')); ?></p>
                                    <div class="clearfix"></div>
                                    <br/>
                                    <div class="col-xs-4 no-padding">
                                        <div class="">
                                            <label for="pic-upload" class="custom-file-upload text-center uppercase">
                                                <?php echo e(__('_store_shopping_cart.upload')); ?>

                                            </label>
                                            <input id="pic-upload" name="payment_receipt" type="file">
                                        </div>
                                    </div>
                                    <div class="clearfix"></div>
                                </div>
                            </div>

                        </div>
                    </form>
                <?php else: ?>
                    <h3><?php echo e(__('_store_shopping_cart.no_products')); ?></h3>
                <?php endif; ?>
            </div>
        </div>
        <?php echo $__env->make('partials._modals', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('bottom_scripts'); ?>
            <?php echo Html::script('public/js/functions.js'); ?>


            <script>
                $(document).ready(function() {
                    $(".remove-from-cart").click(function(e){
                        e.preventDefault();
                        e.stopPropagation();
                        var item = $(this);
                        // if product type 1 else 2
                        remove_from_cart(item.attr('data-id'), item.attr('data-item-id'), '<?php echo e(csrf_token()); ?>');
                        item.parents(".shopping-cart-div").remove();
                        return false;
                    });

                    $(".compare-product").on("click", function(e) {
                        e.preventDefault();
                        e.stopPropagation();
                        var item = $(this);
                        compare_product(item.attr('data-id'), '<?php echo e(csrf_token()); ?>');
                        return false;
                    });
                });
            </script>


            <script>
                $(document).ready(function(){

                    // Smart Wizard events
                    $("#smartwizard").on("leaveStep", function(e, anchorObject, stepNumber, stepDirection) {

                    });

                    // This event should initialize before initializing smartWizard
                    // Otherwise this event wont load on first page load
                    $("#smartwizard").on("showStep", function(e, anchorObject, stepNumber, stepDirection, stepPosition) {
                        $("#message-box").append(" > <strong>showStep</strong> called on " + stepNumber + ". Direction: " + stepDirection+ ". Position: " + stepPosition);
                    });

                    $("#smartwizard").on("beginReset", function(e) {
                        $("#message-box").append("<br /> > <strong>beginReset</strong> called");
                    });

                    $("#smartwizard").on("endReset", function(e) {
                        $("#message-box").append(" > <strong>endReset</strong> called");
                    });

                    $("#smartwizard").on("themeChanged", function(e, theme) {
                        $("#message-box").append("<br /> > <strong>themeChanged</strong> called. New theme: " + theme);
                    });

                    // Toolbar extra buttons
                    var btnFinish = $('<button type="submit"></button>').text('<?php echo e(__('_store_shopping_cart.finish_text')); ?>')
                            .addClass('btn btn-info btn-md btn-finish')
                            .on('click', function(){  });
                    // var btnCancel = $('<button type="button"></button>').text('الغاء')
                    //         .addClass('btn btn-danger btn-md btn-cancel')
                    //         .on('click', function(){ $('#smartwizard').smartWizard("reset"); });
                    var btnCancel = $('<a href="<?php echo e(route("home")); ?>" style="color:white;"></a>').text('<?php echo e(__('_store_shopping_cart.cancel_text')); ?>')
                            .addClass('btn btn-danger btn-md btn-cancel');

                    // Smart Wizard initialize
                    $('#smartwizard').smartWizard({
                        selected: 0,
                        theme: 'dots',
                        transitionEffect:'fade',
                        toolbarSettings: {toolbarPosition: 'bottom',
//                            enableFinishButton: true,
                            toolbarExtraButtons: [btnFinish, btnCancel]
                        },
                        onShowStep: function (objs, context) {
                            $(".btn-cancel, .btn-finish").hide();
                        },
                        onFinish: function (objs, context) {
                            $(".btn-finish").show();
                        }
                    });

                    // External Button Events
                    $("#reset-btn").on("click", function() {
                        // Reset wizard
                        $('#smartwizard').smartWizard("reset");
                        return true;
                    });

                    $("#prev-btn").on("click", function() {
                        // Navigate previous
                        $('#smartwizard').smartWizard("prev");
                        return true;
                    });

                    $("#next-btn").on("click", function() {
                        // Navigate next
                        $('#smartwizard').smartWizard("next");
                        return true;
                    });

                    $("#theme_selector").on("change", function() {
                        // Change theme
                        $('#smartwizard').smartWizard("theme", $(this).val());
                        return true;
                    });

                });

            </script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>