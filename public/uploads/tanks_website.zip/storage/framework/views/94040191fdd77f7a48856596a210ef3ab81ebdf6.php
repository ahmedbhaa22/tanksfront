<?php $__currentLoopData = $branches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="branch item ">
        <div class="col-md-6 no-padding">

            <?php echo $__env->make('partials._map', ['latitude' => Helpers::getCmsKeyValueItemText($branch, "lat"), 'longitude' => Helpers::getCmsKeyValueItemText($branch, "long")], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


        </div>
        <div class="col-md-6 no-padding branches-div">
            <div class="col-xs-12 no-padding">
                <div class="col-xs-11 col-xs-offset-1 ">
                    <h2 class="uppercase">
                        <?php echo e($branch['name']); ?>

                    </h2>
                    <div class="col-md-12 no-padding">
                        <i class="fa fa-map-marker col-md-1"></i>
                        <p class="col-md-11"><?php echo e(Helpers::getCmsKeyValueItemText($branch, "address")); ?></p>
                    </div>
                    <div class="col-md-12 no-padding">
                        <i class="fa fa-envelope col-md-1"></i>
                        <p class="col-md-11">
                            <?php $__currentLoopData = Helpers::getCmsModuleGroup($branch, "email_contacts"); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($item[1]['parameter'] == 'name'): ?>
                                    <a href="mailto:<?php echo e($item[1]['value']); ?>"><?php echo e($item[1]['value']); ?></a>
                                    <?php if(!$loop->last): ?>
                                        <br/>
                                    <?php endif; ?>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </p>
                    </div>
                    <div class="col-md-12 no-padding">
                        <i class="fa fa-phone col-md-1"></i>
                        <p class="col-md-11">
                            <?php $__currentLoopData = Helpers::getCmsModuleGroup($branch, "mobile_contacts"); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($item[1]['parameter'] == 'name'): ?>
                                    <a href="tel:<?php echo e($item[1]['value']); ?>"><?php echo e($item[1]['value']); ?></a>
                                    <?php if(!$loop->last): ?>
                                        <br/>
                                    <?php endif; ?>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>