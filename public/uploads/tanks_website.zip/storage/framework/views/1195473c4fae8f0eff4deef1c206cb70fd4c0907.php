<?php $__env->startSection('title', "Login"); ?>

<?php $__env->startSection('content'); ?>

    <div class="container-fluid no-padding page-body">
        <div class="container">

            <?php echo e(Breadcrumbs::render('login')); ?>


            <div class="container">
                <h3 class="main-title uppercase text-center">
                    <?php echo e(__('_user_login.login')); ?>

                </h3>

                <?php echo $__env->make('partials._formMessages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                <form method="post" class="bordered col-md-6 col-md-offset-3 col-xs-10 col-md-offset-1">
                    <?php echo e(csrf_field()); ?>

                    <div class="form-group float-label-control">
                        <label for=""><?php echo e(__('_user_login.email')); ?></label>
                        <input name="email" type="text" class="form-control" value="<?php echo e(old('email')); ?>">
                    </div>
                    <div class="form-group float-label-control">
                        <label for="password"><?php echo e(__('_user_login.password')); ?></label>
                        <input name="password" type="password" class="form-control" id="password">
                    </div>
                    <button type="submit" class="btn form-submit-btn btn-outline-custom btn-blue uppercase col-xs-12"><?php echo e(__('_user_login.login')); ?></button>
                </form>
                <div class="col-md-6 col-md-offset-3 col-xs-10 col-md-offset-1">
                    <p class="col-md-6"><a href="<?php echo e(url('register')); ?>"><?php echo e(__('_user_login.no_account')); ?></a> </p>
                    <p class="col-md-6"><a href="<?php echo e(url('check-email')); ?>" class="pull-right"><?php echo e(__('_user_login.forgot')); ?></a></p>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>