<?php $__env->startSection('title', "Store"); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid no-padding page-body">
    <div class="container product-details-page">

        <?php echo e(Breadcrumbs::render('store')); ?>


        <?php echo $__env->make('partials._topCategories', ['categories' => $categories], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <div class="row">
            <!-- Load offers and ads block -->
            <?php echo $__env->make('partials._offerAds', ['offers' => $offers, 'ads' => $ads], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
        <div class="clearfix"></div>

        <div class="clearfix"></div>

        <div>
            <div class="col-xs-12 gap">
                <div id="products-wrapper">
                    <?php if($products_all): ?>
                        <?php $__currentLoopData = $products_all; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-lg-3 col-md-4 col-xs-6" >
                                <div class="col-xs-12 no-padding product-list-img-div">
                                    <div class="one-product-container">
                                        <div class="thumbnail one-product-div">
                                            <img src="<?php echo e($product['image']); ?>" class="full-width">
                                            <?php if(Helpers::getProductDataItemFromGroup($product, 'extra', 'discount_percent')!=''): ?>
                                                <span class="product-offer-bar">
                                                            <p> <?php echo e(Helpers::getProductDataItemFromGroup($product, 'extra', 'discount_percent')); ?></p>
                                                    </span>
                                            <?php endif; ?>
                                            <div class="caption">
                                                <a class="<?php echo e(url('store/product-details/'.$product['id'].'/'.Helpers::str2url($product['name']))); ?>"><b><?php echo e($product['name']); ?></b></a>
                                                <?php
                                                    $price = Helpers::getProductDataItemFromGroup($product, 'extra', 'price');
                                                    $old_price = Helpers::getProductDataItemFromGroup($product, 'extra', 'old_price');
                                                ?>

                                                <?php if($price == $old_price || $old_price==0 || $old_price==""): ?>
                                                    <p class="product-price"><?php echo e(Helpers::getProductDataItemFromGroup($product, 'extra', 'price')); ?> <?php echo e(__('_store_shopping_center.sr')); ?>

                                                    </p>
                                                <?php else: ?>
                                                    <p class="product-price"><?php echo e(Helpers::getProductDataItemFromGroup($product, 'extra', 'price')); ?> <?php echo e(__('_store_shopping_center.sr')); ?>

                                                        <strike class="pull-right"><?php echo e(Helpers::getProductDataItemFromGroup($product, 'extra', 'old_price')); ?> <?php echo e(__('_store_shopping_center.sr')); ?></strike>
                                                    </p>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        <div class="overlay thumbnail col-xs-12">
                                            <a href="<?php echo e(url('store/product-details/'.$product['id'].'/'.Helpers::str2url($product['name']))); ?>" class="btn btn-outline-custom btn-white first-btn col-xs-8 col-xs-offset-2"><?php echo e(__('_store_shopping_center.details')); ?></a>
                                            <a href="<?php echo e(url('store/product-details/'.$product['id'].'/'.Helpers::str2url($product['name']))); ?>" class="btn btn-outline-custom btn-white col-xs-8 col-xs-offset-2" data-id="<?php echo e($product['id']); ?>"><?php echo e(__('_store_shopping_center.add_to_cart')); ?></a>
                                            <div class="col-xs-8 col-xs-offset-2 no-padding">
                                                <a href="#" class="btn btn-outline-custom btn-white col-xs-6 add_to_wish_list" data-id="<?php echo e($product['id']); ?>"><i class="fa fa-heart-o"></i></a>
                                                <a href="#" class="btn btn-outline-custom btn-white col-xs-6 compare-product" data-id="<?php echo e($product['id']); ?>"><i class="fa fa-exchange"></i></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </div>
            </div>

        </div>


        <div class="clearfix"></div>
        <hr/>
        
        
        
        <div class="clearfix"></div>
    </div>
</div>
    <?php echo $__env->make('partials._modals', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('bottom_scripts'); ?>
    <?php echo Html::script('public/js/functions.js'); ?>

    <script>
        $(document).ready(function() {
            $(".add_to_wish_list").on("click", function(e) {
                e.preventDefault();
                e.stopPropagation();
                var item = $(this);
                add_to_wish_List(item.attr('data-id'), 1, '<?php echo e(csrf_token()); ?>');

                return false;
            });

            $(".compare-product").on("click", function(e) {
                e.preventDefault();
                e.stopPropagation();
                var item = $(this);
                compare_product(item.attr('data-id'), '<?php echo e(csrf_token()); ?>');
                return false;
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>