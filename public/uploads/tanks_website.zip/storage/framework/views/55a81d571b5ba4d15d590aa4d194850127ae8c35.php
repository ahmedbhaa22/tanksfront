<div class="col-md-3 col-sm-5 col-xs-12 account-info-div">
    <div class="account-side-bar bordred-account-div">
        <div class="account-info">
            <div class="row">
                <div class="col-xs-6 col-xs-offset-3">
                    <form id="change_profile_image_form" role="form" enctype="multipart/form-data" method="post" action="<?php echo e(route('change-profile-image')); ?>">
                        <?php echo e(csrf_field()); ?>

                        <input type="file" id="profile_img_input" name="profile_img" style="display: none" onchange="readURL(this)">
                        <?php if(Session::has('Img') && Session::get('Img') != ''): ?>
                            <a id="change_profile" href="#">
                                <img class="img-circle full-width account-img" src="<?php echo e(config('app.api_endpoints.backend_url') . Session::get('Img')); ?>" />
                            </a>
                        <?php else: ?>
                        <a id="change_profile" href="#">
                            <img class="img-circle full-width account-img" src="<?php echo e(asset('public/img/default-avatar.jpg')); ?>" />
                        </a>
                        <?php endif; ?>
                    </form>
                </div>
            </div>
            <h3 class="uppercase col-md-12 text-center"><?php echo e(Session::get('name')); ?></h3>
            <p class="col-md-12">
                <a class="text-center" href="mailto:<?php echo e(Session::get('email')); ?>"><?php echo e(Session::get('email')); ?></a></p>
        </div>
        <a href="<?php echo e(route('user-orders')); ?>" class="<?php echo e(Request::is("user-orders")?'active':''); ?>"><i class="fa fa-shopping-bag col-md-2 col-xs-2"></i><?php echo e(__('_user_shipping_addresses.my_orders')); ?></a>
        <a href="<?php echo e(route('shipping-addresses')); ?>" class="<?php echo e(Request::is("shipping-addresses")?'active':''); ?>"><i class="fa fa-map-marker col-md-2 col-xs-2"></i><?php echo e(__('_user_shipping_addresses.shipping_addresses')); ?></a>
        <a href="<?php echo e(route('account-settings')); ?>" class="<?php echo e(Request::is("account-settings")?'active':''); ?>"><i class="fa fa-gear col-md-2 col-xs-2"></i><?php echo e(__('_user_shipping_addresses.settings')); ?></a>
        <a style="padding-top: 10px;color: black;" href="<?php echo e(route('logout')); ?>" class="btn form-submit-btn btn-block-white uppercase col-xs-8 col-xs-offset-2 no-padding"><?php echo e(__('_user_shipping_addresses.logout')); ?></a>
    </div>
</div>
<script type="text/javascript">
$('#change_profile').on('click', function()
{
   $('#profile_img_input').trigger('click');
});

function readURL(input)
{
    if(input.files && input.files[0])
    {
        var reader = new FileReader();

        reader.onload = function(e)
        {
            $('.img-circle').attr('src', e.target.result);
        };

        reader.readAsDataURL(input.files[0]);

        $('#change_profile_image_form').submit();
    }
}
</script>