<?php $__env->startSection('title', 'Home'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid no-padding page-body">
<div class="container">

    <!-- Load messages -->
<?php echo $__env->make('partials._messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<!-- Load offers and ads block -->
    <?php echo $__env->make('partials._offerAds', ['offers' => $offers, 'ads' => $ads], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="clearfix"></div>

</div>
<div class="container">
    
    <div class="col-md-12">
        <h4 class="uppercase main-title">
            <?php echo e(__('_site_home.categories_services')); ?>

            <span class="pull-right"></span>
        </h4>
        <div class="category-home swiper-container">
            <div class="swiper-wrapper">

                <?php if(count($productCategories)): ?>
                    <?php $__currentLoopData = $productCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e(url('product-category/'.$cat['id'].'/'.Helpers::str2url($cat['name']))); ?>" class="swiper-slide category-one">
                            <div class="cat-img" style="background-image:url('<?php echo e($cat['image']); ?>')">
                            </div>
                            <div class="cat-desc">
                                <h2><?php echo e($cat['name']); ?></h2>
                            </div>
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </div>
            <div class="swiper-pagination"></div>
        </div>
        <hr>
        

    </div>
    <div class="clearfix"></div>
    <div class="col-md-12">
        <h4 class="uppercase main-title">
            <?php echo e(__('_site_home.most_selling_services')); ?>

            <span class="pull-right"></span>
        </h4>
        <div class="col-xs-12 gap">
            <div class="category-two-swiper-container swiper-container">
                <div class="swiper-wrapper">
                    <?php if($products && count($products) > 0): ?>
                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="swiper-slide">
                                <div class="one-product-container">
                                    <div class="thumbnail one-product-div">
                                        <div class="one-product-img">
                                            <img src="<?php echo e($product['image']); ?>" class="full-width">
                                        </div>
                                        <div class="caption">
                                            <a class="<?php echo e(url('store/product-details/'.$product['id'].'/'.Helpers::str2url($product['name']))); ?>"><b><?php echo e($product['name']); ?></b></a>
                                            <p class="product-price"><?php echo e(Helpers::getProductDataItemFromGroup($product, 'extra', 'price')); ?> <?php echo e(__('_store_home.sr')); ?>

                                               <?php if(Helpers::getProductDataItemFromGroup($product, 'extra', 'price')!=Helpers::getProductDataItemFromGroup($product, 'extra', 'old_price') && Helpers::getProductDataItemFromGroup($product, 'extra', 'old_price') > Helpers::getProductDataItemFromGroup($product, 'extra', 'price') && Helpers::getProductDataItemFromGroup($product, 'extra', 'old_price')!=0 ): ?>
                                                <strike class="pull-right"><?php echo e(Helpers::getProductDataItemFromGroup($product, 'extra', 'old_price')); ?> <?php echo e(__('_store_home.sr')); ?></strike>
                                                <?php endif; ?>
                                            </p>
                                        </div>
                                    </div>
                                    <div class="overlay thumbnail">
                                        <a href="<?php echo e(url('store/product-details/'.$product['id'].'/'.Helpers::str2url($product['name']))); ?>" class="btn btn-outline-custom btn-white first-btn col-md-8 col-md-offset-2 col-xs-10 col-xs-offset-1"><?php echo e(__('_store_home.details')); ?></a>
                                        <a href="<?php echo e(url('store/product-details/'.$product['id'].'/'.Helpers::str2url($product['name']))); ?>" class="btn btn-outline-custom btn-white col-md-8 col-md-offset-2 col-xs-10 col-xs-offset-1" data-id="<?php echo e($product['id']); ?>"><?php echo e(__('_store_home.add_to_cart')); ?></a>
                                        <div class="col-md-8 col-md-offset-2 col-xs-10 col-xs-offset-1 no-padding">
                                            <a href="#" class="btn btn-outline-custom btn-white col-xs-6 add_to_wish_list" data-id="<?php echo e($product['id']); ?>"><i class="fa fa-heart-o"></i></a>
                                            <a href="#" class="btn btn-outline-custom btn-white col-xs-6 compare-product" data-id="<?php echo e($product['id']); ?>"><i class="fa fa-exchange"></i></a>
                                        </div>

                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <?php echo e(__('_store_home.no_most_selling')); ?>

                    <?php endif; ?>
                </div>
            </div>
        </div>




    </div>

    <div class="clearfix"></div>
    <hr>
    <div class="col-md-4 col-sm-12 col-xs-12">
        
        
        

        
        <div class="events-section events-page">
            <div class="home-section home-events-section">
                <h4 class="uppercase main-title">
                    <a href="#"><?php echo e(__('_site_home.about_us')); ?></a>
                    <span class="pull-right"><i class="fa fa-calendar" aria-hidden="true"></i></span>
                </h4>
                <p>
                    <?php echo e($about['description']); ?>

                </p>
                <?php $__currentLoopData = $about['media']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $media): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-2 col-sm-6 col-xs-12  no-padding">
                        <?php if($media['type'] == "Video"): ?>
                            <?php if(strlen($media['link'])): ?>
                                <a href="<?php echo e($media['link']); ?>" item-type="video" item-video-id="<?php echo e((Helpers::getYoutubeVideoId($media['link']))); ?>" class="gal-item">
                                <i class="fa fa-play-circle-o"></i>
                                <img src="<?php echo e($media['image']); ?>"
                                     class="full-width centered-and-cropped"/>
                                </a>
                            <?php endif; ?>
                        <?php else: ?>
                            <a href="<?php echo e($media['image']); ?>" item-type="image" class="gal-item">
                                <img src="<?php echo e($media['image']); ?>" class="full-width centered-and-cropped"/>
                            </a>
                        <?php endif; ?>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <div class="clearfix"></div>
            </div>
        </div>
        
    </div>
    <div class="col-md-4 col-sm-6 col-xs-12 facebook-feed">
        <img src="https://www.socialsamosa.com/wp-content/uploads/2012/09/Like-Box.jpg" class="img-responsive">
    </div>

    <div class="col-md-4 col-sm-6 col-xs-12 twitter-feed">
        <a class="twitter-timeline" href="https://twitter.com/TwitterDev/timelines/539487832448843776">National Park Tweets - Curated tweets by TwitterDev</a> <script async src="//platform.twitter.com/widgets.js" charset="utf-8"></script>
    </div>
        
</div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>