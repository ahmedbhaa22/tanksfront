<?php if($offers): ?>
    <?php $__currentLoopData = $offers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $offer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-lg-3 col-md-4 col-xs-6  product-list-img-div">
            <div class="one-product-container">
                <div class="thumbnail one-product-div">
                    <img src="<?php echo e($offer['image']); ?>" class="full-width">
                    <div class="caption">
                        <a class="<?php echo e(url('store/offer-details/'.$offer['id'].'/'.Helpers::str2url($offer['name']))); ?>"><b><?php echo e($offer['name']); ?></b></a>
                        <p class="product-price"><?php echo e(Helpers::getProductKeyValueItemText($offer, 'price')); ?> SAR
                            <strike class="pull-right"><?php echo e(Helpers::getProductKeyValueItemText($offer, 'original_price')); ?> SAR</strike>
                        </p>
                    </div>
                </div>
                <div class="overlay thumbnail col-xs-12">
                    <a href="<?php echo e(url('store/offer-details/'.$offer['id'].'/'.Helpers::str2url($offer['name']))); ?>" class="btn btn-outline-custom btn-white first-btn col-xs-8 col-xs-offset-2">التفاصيل</a>
                    <a href="<?php echo e(url('store/offer-details/'.$offer['id'].'/'.Helpers::str2url($offer['name']))); ?>" class="btn btn-outline-custom btn-white col-xs-8 col-xs-offset-2" data-id="<?php echo e($offer['id']); ?>">اضف لعربة التسوق</a>
                    <a href="#" class="btn btn-outline-custom btn-white col-xs-4 col-xs-offset-4 add_to_wish_list" data-id="<?php echo e($offer['id']); ?>"><i class="fa fa-heart-o"></i></a>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>

<?php echo Html::script('public/js/functions.js'); ?>



<script>
    $(document).ready(function () {
        
            
            
            
            
        

        $(".add_to_wish_list").on("click", function(e){
            e.preventDefault();
            e.stopPropagation();
            var item = $(this);
            add_to_wish_List(item.attr('data-id'), 2, '<?php echo e(csrf_token()); ?>');
        });
    });
</script>