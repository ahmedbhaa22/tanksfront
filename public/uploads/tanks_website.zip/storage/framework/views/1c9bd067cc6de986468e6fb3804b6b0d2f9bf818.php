<?php if(Session::has('error')): ?>
    <?php $error = Session::get('error'); ?>
    <div class="alert alert-danger alert-dismissable">
        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
        <strong><?php echo e(__('messages.validation_failed')); ?></strong>
        <?php if(isset($error['message'])): ?>
            <ul>
                <li><?php echo e($error['message']); ?></li>
            </ul>
        <?php endif; ?>
        <?php if(isset($error['summary'])): ?>
            <ul>
                <?php $__currentLoopData = $error['summary']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if(is_array($sm) && isset($sm['message'])): ?>
                        <li><?php echo e($sm['message']); ?></li>
                    <?php else: ?>
                        <li><?php echo e($sm); ?></li>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        <?php endif; ?>
    </div>
<?php endif; ?>

<?php if(Session::has('success')): ?>
    <div class="alert alert-success alert-dismissable">
        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
        <span><?php echo e(Session::get('success')['message']); ?></span>
    </div>
<?php endif; ?>