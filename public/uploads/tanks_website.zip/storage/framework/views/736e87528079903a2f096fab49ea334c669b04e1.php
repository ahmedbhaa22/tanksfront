<?php $__env->startSection('title', "Reset Password"); ?>

<?php $__env->startSection('content'); ?>

    <div class="container-fluid no-padding page-body">
        <div class="container">

            <?php echo e(Breadcrumbs::render('reset-password')); ?>


            <div class="container">
                <h3 class="main-title uppercase text-center">
                    <?php echo e(__('_user_reset_password.reset')); ?>

                </h3>

                <?php echo $__env->make('partials._formMessages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                <form method="post" class="bordered col-md-6 col-md-offset-3 col-xs-10 col-md-offset-1">
                    <?php echo e(csrf_field()); ?>

                    <div class="form-group  float-label-control">
                        <label><?php echo e(__('_user_reset_password.password')); ?></label>
                        <input type="password" class="form-control" name="password" value="">
                    </div>
                    <div class="form-group  float-label-control">
                        <label><?php echo e(__('_user_reset_password.confirm_password')); ?></label>
                        <input type="password" class="form-control" name="confirm_password" value="">
                    </div>
                    <button type="submit" class="btn form-submit-btn btn-outline-custom btn-blue col-xs-12"><?php echo e(__('_user_reset_password.reset_send')); ?></button>
                </form>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>