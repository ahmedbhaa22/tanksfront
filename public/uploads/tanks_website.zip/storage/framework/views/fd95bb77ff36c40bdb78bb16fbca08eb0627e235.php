<?php $__env->startSection('title', "User Orders"); ?>

<?php $__env->startSection('content'); ?>

    <div class="container-fluid no-padding page-body">
        <div class="container">

            <?php echo e(Breadcrumbs::render('user-orders')); ?>


            <div class="container account-div">

                <?php echo $__env->make('partials._userProfileSidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                <div class="bordred-account-div col-md-9 col-sm-7 col-xs-12">
                    <div class="col-xs-12 no-padding">

                        <h3 class=" uppercase">
                            <?php echo e(__('_user_orders.orders')); ?>

                        </h3>

                        <?php if($orders): ?>
                            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="panel panel-default">
                                    <div class="panel-body">
                                <div class="col-md-6"><p><b><?php echo e(__('_user_orders.order_no')); ?></b><?php echo e($order['id']); ?></p></div>
                                <div class="col-md-6"><p class="pull-right"><span class="label label-primary"> <?php echo e($order['status_name']); ?> </span></p>
                                </div>
                                <div class="col-md-6"><p><b><?php echo e(__('_user_orders.total_price')); ?></b><?php echo e($order['total_price']); ?></p></div>
                                <div class="col-md-6 ">
                                    <!-- <label for="pic-upload" class="custom2-file-upload text-info bold">
                                    ارفع صورة ايصال الايداع <i class="fa fa-cloud-upload "></i>
                                </label>
                                    <input id="pic-upload" type="file"> -->
                                    <p class="pull-right"><b> <i class="fa fa-calendar"></i> &nbsp; </b> <?php echo e(date('m/d/Y', $order['date'])); ?></p>
                                </div>

                                <div class="clearfix"></div>
                                       <div class="row">
                                           <a href="#"><?php echo e(__('_user_orders.add_purchase_prove')); ?></a>
                                           
                                       </div>

                            </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>