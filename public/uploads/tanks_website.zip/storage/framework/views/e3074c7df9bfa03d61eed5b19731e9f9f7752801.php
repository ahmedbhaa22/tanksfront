<?php $__env->startSection('title', "404 Not Found"); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid no-padding about-page page-body">
        <div class="container">

            <div class="container">

                <h3 class="main-title uppercase text-center">
                    404 Not Found
                </h3>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>