<nav class="navbar navbar-default sec-nav">
    <div class="container">
        <ul class="nav navbar-nav">
            <?php if($categories): ?>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="uppercase"><a class="" href="<?php echo e(url('store/shopping-center?filterCategory[]='.$cat['id'])); ?>"><?php echo e($cat['name']); ?></a></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </ul>
        <ul class="nav navbar-nav">
            <li class="uppercase"><a href="<?php echo e(url('store/offers')); ?>" class="orange-txt"><?php echo e(__('_top_categories.offers_and_more')); ?></a></li>
        </ul>
    </div>
</nav>